// src/index.ts
import * as fs2 from "fs";
import * as path2 from "path";
import * as os2 from "os";
import { tool } from "@opencode-ai/plugin";

// src/statePathResolver.ts
import * as fs from "fs";
import * as path from "path";
import * as os from "os";
var _resolvedVSCodeStatePath = null;
function getIDEBase() {
  return process.platform === "win32" ? process.env["APPDATA"] ?? path.join(os.homedir(), "AppData", "Roaming") : path.join(os.homedir(), ".config");
}
function resolveVSCodeStatePath() {
  if (_resolvedVSCodeStatePath !== null)
    return _resolvedVSCodeStatePath;
  const base = path.join(getIDEBase(), "codotchi", "vscode");
  const global = path.join(base, "state.json");
  try {
    if (!fs.existsSync(base))
      return _resolvedVSCodeStatePath = global;
    const candidates = [];
    if (fs.existsSync(global)) {
      candidates.push({ filePath: global, mtime: fs.statSync(global).mtimeMs });
    }
    for (const entry of fs.readdirSync(base, { withFileTypes: true })) {
      if (entry.isDirectory() && /^[0-9a-f]{12}$/.test(entry.name)) {
        const candidate = path.join(base, entry.name, "state.json");
        if (fs.existsSync(candidate)) {
          candidates.push({ filePath: candidate, mtime: fs.statSync(candidate).mtimeMs });
        }
      }
    }
    if (candidates.length === 0)
      return _resolvedVSCodeStatePath = global;
    candidates.sort((a, b) => b.mtime - a.mtime);
    return _resolvedVSCodeStatePath = candidates[0].filePath;
  } catch {
    return _resolvedVSCodeStatePath = global;
  }
}

// src/usageBackfill.ts
function sumCompletedAssistantUsage(messages) {
  let costUSD = 0;
  let tokens = 0;
  for (const m of messages) {
    const info = m.info;
    if (info.role !== "assistant") {
      continue;
    }
    if (!info.time?.completed) {
      continue;
    }
    const cost = typeof info.cost === "number" && !isNaN(info.cost) ? info.cost : 0;
    const t = (info.tokens?.input ?? 0) + (info.tokens?.output ?? 0) + (info.tokens?.reasoning ?? 0) + (info.tokens?.cache?.read ?? 0) + (info.tokens?.cache?.write ?? 0);
    costUSD += cost;
    tokens += t;
  }
  return { costUSD, tokens };
}

// src/gameEngine.ts
var TICK_INTERVAL_SECONDS = 3;
var DECAY_TICK_INTERVAL = 6;
var AGING_TICK_INTERVAL = 3;
var TICKS_PER_MINUTE = 60 / TICK_INTERVAL_SECONDS;
var TICKS_PER_HOUR = 60 * TICKS_PER_MINUTE;
var EGG_DURATION_TICKS = 2 * TICKS_PER_MINUTE;
var BABY_DURATION_TICKS = 28 * TICKS_PER_MINUTE;
var CHILD_DURATION_TICKS = 90 * TICKS_PER_MINUTE;
var TEEN_DURATION_TICKS = 6 * TICKS_PER_HOUR;
var ADULT_DURATION_TICKS = 16 * TICKS_PER_HOUR;
var STAT_MIN = 0;
var STAT_MAX = 100;
var WEIGHT_MIN = 1;
var WEIGHT_MAX = 99;
var HUNGER_DECAY_PER_TICK = 1;
var HAPPINESS_DECAY_PER_TICK = 1;
var ENERGY_REGEN_PER_TICK_SLEEPING = 3;
var HUNGER_CRITICAL_THRESHOLD = 10;
var HAPPINESS_CRITICAL_THRESHOLD = 10;
var HEALTH_DEATH_THRESHOLD = 0;
var HUNGER_ZERO_TICKS_BEFORE_RISK = 3;
var CRITICAL_HEALTH_DAMAGE_PER_TICK = 5;
var MAX_UNCLEANED_POOPS_BEFORE_SICK = 3;
var RECENT_EVENT_LOG_MAX = 20;
var POOP_TICKS_INTERVAL = 20 * TICKS_PER_MINUTE;
var FEED_MEAL_HUNGER_BOOST = 20;
var FEED_MEAL_WEIGHT_GAIN = 2;
var FEED_MEAL_MAX_PER_CYCLE = 3;
var PAT_HAPPINESS_BOOST = 10;
var PAT_ENERGY_COST = 20;
var PAT_WEIGHT_LOSS = 3;
var POOP_WEIGHT_LOSS = 5;
var WEIGHT_DECAY_TICK_INTERVAL = TICKS_PER_MINUTE;
var WEIGHT_HAPPINESS_HIGH_THRESHOLD = 66;
var WEIGHT_HAPPINESS_LOW_THRESHOLD = 17;
var WEIGHT_HAPPINESS_DEBUFF_MULTIPLIER = 1.5;
var WEIGHT_SLIGHTLY_FAT_THRESHOLD = 50;
var WEIGHT_OVERWEIGHT_THRESHOLD = 80;
var ENERGY_DECAY_PER_TICK = 1;
var EXHAUSTION_HEALTH_DAMAGE_PER_TICK = 2;
var IDLE_SICK_DAMAGE_PER_TICK = 1;
var SLEEP_SICK_RECOVERY_CHANCE = 0.03;
var SLEEP_DECAY_TICK_INTERVAL = 5;
var MEDICINE_DOSES_TO_CURE = 3;
var HEALTH_REGEN_AWAKE_TICK_INTERVAL = 5;
var CODE_ACTIVITY_HAPPINESS_BOOST = 8;
var CODE_ACTIVITY_DISCIPLINE_BOOST = 2;
var CODE_ACTIVITY_THROTTLE_SECONDS = 10;
var IDLE_STAT_FLOOR = 20;
var IDLE_DECAY_TICK_DIVISOR = 20;
var CARE_SCORE_HUNGER_WEIGHT = 0.3;
var CARE_SCORE_HAPPINESS_WEIGHT = 0.25;
var CARE_SCORE_DISCIPLINE_WEIGHT = 0.2;
var CARE_SCORE_CLEANLINESS_WEIGHT = 0.15;
var CARE_SCORE_HEALTH_WEIGHT = 0.1;
var CARE_SCORE_BEST_TIER_THRESHOLD = 0.8;
var CARE_SCORE_MID_TIER_THRESHOLD = 0.55;
var OFFLINE_DECAY_MAX_FRACTION = 0.6;
var ATTENTION_CALL_RESPONSE_TICKS = 20;
var ATTENTION_HUNGER_THRESHOLD = 25;
var ATTENTION_UNHAPPINESS_THRESHOLD = 40;
var ATTENTION_ENERGY_THRESHOLD = 20;
var ATTENTION_HEALTH_THRESHOLD = 50;
var ATTENTION_ANSWER_COOLDOWN_TICKS = 50;
var ATTENTION_EXPIRY_COOLDOWN_TICKS = 20;
var ATTENTION_EXPIRY_STAT_PENALTY = 10;
var CARE_MISTAKE_BEST_MAX = 3;
var CARE_MISTAKE_MID_MAX = 6;
var CARE_MISTAKE_DELAY_THRESHOLD = CARE_MISTAKE_BEST_MAX;
var CARE_MISTAKE_DAYS_PER_EXCESS = 1;
var CARE_MISTAKE_DELAY_MAX_DAYS = 9;
var CARE_MISTAKE_FORGIVENESS_DAYS = 2;
var CARE_MISTAKE_ANSWER_CREDIT = 0.5;
var CARE_MISTAKE_SECRET_WORST_THRESHOLD = 10;
var CARE_MISTAKE_SECRET_BEST_CARE_SCORE = 0.95;
var CARE_MISTAKE_OLD_AGE_SATURATE = 20;
var POOP_CALL_BASE_CHANCE = 0.03;
var POOP_CALL_MAX_CHANCE = 0.12;
var MISBEHAVIOUR_BASE_CHANCE = 0.005;
var MISBEHAVIOUR_MAX_CHANCE = 0.08;
var GIFT_BASE_CHANCE = 0.002;
var GIFT_MAX_CHANCE = 0.05;
var SENIOR_NATURAL_DEATH_AGE_DAYS = 365;
var OLD_AGE_DEATH_BASE_CHANCE_PER_DAY = 0.001;
var OLD_AGE_DEATH_RISK_MULTIPLIER = 9;
var OLD_AGE_DEATH_PEAK_AGE_DAYS = 1825;
var OLD_AGE_DEATH_PEAK_BEST_CARE_CHANCE = 0.05;
var OLD_AGE_DEATH_PEAK_WORST_CARE_CHANCE = 0.1;
var OLD_AGE_SICK_CHANCE_MULTIPLIER = 3;
var TICKS_PER_GAME_DAY_AWAKE = 5 * TICKS_PER_MINUTE;
var TICKS_PER_GAME_DAY_SLEEPING = Math.round(5 * TICKS_PER_MINUTE * 0.8);
var DEFAULT_GAME_CONFIG = {
  attentionCallsEnabled: true,
  attentionCallExpiryTicks: 50,
  attentionCallRateDivisor: 1,
  devMode: false,
  devModeAgingMultiplier: 10,
  devModeHealthFloor: 1
};
var PET_TYPE_MODIFIERS = {
  codeling: {
    hungerDecayMultiplier: 1,
    happinessDecayMultiplier: 1,
    baseHealth: 100,
    energyRegenMultiplier: 1,
    poopIntervalMultiplier: 0.75,
    poopIntervalVolatility: 0.5,
    agingMultiplier: 1
  },
  bytebug: {
    hungerDecayMultiplier: 1.5,
    happinessDecayMultiplier: 1,
    baseHealth: 100,
    energyRegenMultiplier: 1.2,
    poopIntervalMultiplier: 0.4,
    poopIntervalVolatility: 0.8,
    agingMultiplier: 1.5
  },
  pixelpup: {
    hungerDecayMultiplier: 1,
    happinessDecayMultiplier: 1.5,
    baseHealth: 100,
    energyRegenMultiplier: 1,
    poopIntervalMultiplier: 0.6,
    poopIntervalVolatility: 0.7,
    agingMultiplier: 1.25
  },
  shellscript: {
    hungerDecayMultiplier: 0.8,
    happinessDecayMultiplier: 1,
    baseHealth: 120,
    energyRegenMultiplier: 1,
    poopIntervalMultiplier: 1,
    poopIntervalVolatility: 0.2,
    agingMultiplier: 0.75
  }
};
var VALID_PET_TYPES = Object.keys(PET_TYPE_MODIFIERS);
var EVOLUTION_CHARACTERS = {
  codeling: {
    baby: { best: "codeling_baby_a", mid: "codeling_baby_b", low: "codeling_baby_c", secret_best: "codeling_baby_a", secret_worst: "codeling_baby_c" },
    child: { best: "codeling_child_a", mid: "codeling_child_b", low: "codeling_child_c", secret_best: "codeling_child_a", secret_worst: "codeling_child_c" },
    teen: { best: "codeling_teen_a", mid: "codeling_teen_b", low: "codeling_teen_c", secret_best: "codeling_teen_a", secret_worst: "codeling_teen_c" },
    adult: { best: "codeling_adult_a", mid: "codeling_adult_b", low: "codeling_adult_c", secret_best: "codeling_adult_a", secret_worst: "codeling_adult_c" },
    senior: { best: "codeling_senior_a", mid: "codeling_senior_b", low: "codeling_senior_c", secret_best: "codeling_senior_a", secret_worst: "codeling_senior_c" }
  },
  bytebug: {
    baby: { best: "bytebug_baby_a", mid: "bytebug_baby_b", low: "bytebug_baby_c", secret_best: "bytebug_baby_a", secret_worst: "bytebug_baby_c" },
    child: { best: "bytebug_child_a", mid: "bytebug_child_b", low: "bytebug_child_c", secret_best: "bytebug_child_a", secret_worst: "bytebug_child_c" },
    teen: { best: "bytebug_teen_a", mid: "bytebug_teen_b", low: "bytebug_teen_c", secret_best: "bytebug_teen_a", secret_worst: "bytebug_teen_c" },
    adult: { best: "bytebug_adult_a", mid: "bytebug_adult_b", low: "bytebug_adult_c", secret_best: "bytebug_adult_a", secret_worst: "bytebug_adult_c" },
    senior: { best: "bytebug_senior_a", mid: "bytebug_senior_b", low: "bytebug_senior_c", secret_best: "bytebug_senior_a", secret_worst: "bytebug_senior_c" }
  },
  pixelpup: {
    baby: { best: "pixelpup_baby_a", mid: "pixelpup_baby_b", low: "pixelpup_baby_c", secret_best: "pixelpup_baby_a", secret_worst: "pixelpup_baby_c" },
    child: { best: "pixelpup_child_a", mid: "pixelpup_child_b", low: "pixelpup_child_c", secret_best: "pixelpup_child_a", secret_worst: "pixelpup_child_c" },
    teen: { best: "pixelpup_teen_a", mid: "pixelpup_teen_b", low: "pixelpup_teen_c", secret_best: "pixelpup_teen_a", secret_worst: "pixelpup_teen_c" },
    adult: { best: "pixelpup_adult_a", mid: "pixelpup_adult_b", low: "pixelpup_adult_c", secret_best: "pixelpup_adult_a", secret_worst: "pixelpup_adult_c" },
    senior: { best: "pixelpup_senior_a", mid: "pixelpup_senior_b", low: "pixelpup_senior_c", secret_best: "pixelpup_senior_a", secret_worst: "pixelpup_senior_c" }
  },
  shellscript: {
    baby: { best: "shellscript_baby_a", mid: "shellscript_baby_b", low: "shellscript_baby_c", secret_best: "shellscript_baby_a", secret_worst: "shellscript_baby_c" },
    child: { best: "shellscript_child_a", mid: "shellscript_child_b", low: "shellscript_child_c", secret_best: "shellscript_child_a", secret_worst: "shellscript_child_c" },
    teen: { best: "shellscript_teen_a", mid: "shellscript_teen_b", low: "shellscript_teen_c", secret_best: "shellscript_teen_a", secret_worst: "shellscript_teen_c" },
    adult: { best: "shellscript_adult_a", mid: "shellscript_adult_b", low: "shellscript_adult_c", secret_best: "shellscript_adult_a", secret_worst: "shellscript_adult_c" },
    senior: {
      best: "shellscript_senior_a",
      mid: "shellscript_senior_b",
      low: "shellscript_senior_c",
      secret_best: "shellscript_senior_a",
      secret_worst: "shellscript_senior_c"
    }
  }
};
function clamp(value, minimum, maximum) {
  return Math.max(minimum, Math.min(maximum, value));
}
function clampStat(value) {
  return clamp(value, STAT_MIN, STAT_MAX);
}
function clampWeight(value) {
  return clamp(value, WEIGHT_MIN, WEIGHT_MAX);
}
function logChance(ticksSinceLast, base, max) {
  return Math.min(max, base * Math.log(ticksSinceLast + Math.E));
}
function sampleNextPoopInterval(petType) {
  const mods = PET_TYPE_MODIFIERS[petType] ?? PET_TYPE_MODIFIERS.codeling;
  const base = POOP_TICKS_INTERVAL * mods.poopIntervalMultiplier;
  const jitter = base * mods.poopIntervalVolatility;
  const raw = base - jitter + Math.random() * 2 * jitter;
  return Math.max(1, Math.min(POOP_TICKS_INTERVAL, Math.round(raw)));
}
function moodFromStats(hunger, happiness, health, sleeping) {
  if (sleeping) {
    return "sleeping";
  }
  if (health < 30) {
    return "sick";
  }
  if (hunger < HUNGER_CRITICAL_THRESHOLD) {
    return "sad";
  }
  if (happiness < HAPPINESS_CRITICAL_THRESHOLD) {
    return "sad";
  }
  if (happiness >= 70 && hunger >= 50) {
    return "happy";
  }
  return "neutral";
}
function tierFromCareScore(careScore) {
  if (careScore >= CARE_SCORE_BEST_TIER_THRESHOLD) {
    return "best";
  }
  if (careScore >= CARE_SCORE_MID_TIER_THRESHOLD) {
    return "mid";
  }
  return "low";
}
function tierFromState(careScore, careMistakes, lifetimeCareMistakes) {
  if (lifetimeCareMistakes >= CARE_MISTAKE_SECRET_WORST_THRESHOLD) {
    return "secret_worst";
  }
  if (careMistakes === 0 && careScore >= CARE_MISTAKE_SECRET_BEST_CARE_SCORE) {
    return "secret_best";
  }
  const scoreTier = tierFromCareScore(careScore);
  if (careMistakes > CARE_MISTAKE_MID_MAX) {
    return "low";
  }
  if (careMistakes > CARE_MISTAKE_BEST_MAX && scoreTier === "best") {
    return "mid";
  }
  return scoreTier;
}
function characterForStage(petType, stage, careScore, careMistakes = 0, lifetimeCareMistakes = 0) {
  const tier = tierFromState(careScore, careMistakes, lifetimeCareMistakes);
  return EVOLUTION_CHARACTERS[petType][stage][tier];
}
function computeCareScore(state) {
  if (state.careScoreTicks === 0) {
    return 0.5;
  }
  const averageHunger = state.careScoreHungerSum / state.careScoreTicks;
  const averageHappiness = state.careScoreHappinessSum / state.careScoreTicks;
  const averageHealth = state.careScoreHealthSum / state.careScoreTicks;
  const cleanlinessNormalised = clampStat(100 - state.poops * 20) / STAT_MAX;
  return CARE_SCORE_HUNGER_WEIGHT * (averageHunger / STAT_MAX) + CARE_SCORE_HAPPINESS_WEIGHT * (averageHappiness / STAT_MAX) + CARE_SCORE_DISCIPLINE_WEIGHT * (state.discipline / STAT_MAX) + CARE_SCORE_CLEANLINESS_WEIGHT * cleanlinessNormalised + CARE_SCORE_HEALTH_WEIGHT * (averageHealth / STAT_MAX);
}
var ROTATION_ANIMALS = [
  "cat",
  "dog",
  "snake",
  "sheep",
  "classic",
  "rooster",
  "tiger",
  "kangaroo"
];
function randomSpriteType() {
  return ROTATION_ANIMALS[Math.floor(Math.random() * ROTATION_ANIMALS.length)];
}
function createPet(name, petType, unlockedCharacter = null) {
  const modifiers = PET_TYPE_MODIFIERS[petType] ?? PET_TYPE_MODIFIERS.codeling;
  const baseHealth = modifiers.baseHealth;
  const resolvedName = name;
  const resolvedSprite = unlockedCharacter ?? randomSpriteType();
  const partial = {
    name: resolvedName,
    petType,
    spriteType: resolvedSprite,
    hunger: 50,
    happiness: 50,
    discipline: 50,
    energy: 100,
    health: baseHealth,
    weight: 40,
    ageDays: 0,
    stage: "egg",
    character: "",
    alive: true,
    sick: false,
    sleeping: false,
    ticksAlive: 0,
    poops: 0,
    ticksSinceLastPoop: 0,
    nextPoopIntervalTicks: sampleNextPoopInterval(petType),
    consecutiveSnacks: 0,
    hungerZeroTicks: 0,
    medicineDosesGiven: 0,
    careScoreHungerSum: 0,
    careScoreHappinessSum: 0,
    careScoreHealthSum: 0,
    careScoreTicks: 0,
    events: [],
    recentEventLog: [],
    wasIdle: false,
    wasDeepIdle: false,
    spawnedAt: Date.now(),
    snacksGivenThisCycle: 0,
    snacksOnFloor: 0,
    paused: false,
    dayTimer: 0,
    activeAttentionCall: null,
    attentionCallActiveTicks: 0,
    attentionCallCooldowns: {},
    careMistakes: 0,
    lifetimeCareMistakes: 0,
    ticksWithUncleanedPoop: 0,
    ticksSinceLastMisbehaviour: 0,
    ticksSinceLastGift: 0
  };
  return withDerivedFields(partial);
}
function withDerivedFields(partial) {
  const careScore = computeCareScore(partial);
  const mood = moodFromStats(partial.hunger, partial.happiness, partial.health, partial.sleeping);
  const sprite = `${partial.stage}_${mood}`;
  const SILENT_EVENTS = new Set(["game_paused", "game_resumed", "snack_placed"]);
  const loggableEvents = partial.events.filter((e) => !SILENT_EVENTS.has(e));
  const newLog = loggableEvents.length > 0 ? [...partial.recentEventLog, ...loggableEvents].slice(-RECENT_EVENT_LOG_MAX) : partial.recentEventLog;
  return { ...partial, careScore: Math.round(careScore * 1e4) / 1e4, mood, sprite, recentEventLog: newLog };
}
function weightTierOf(w) {
  if (w > WEIGHT_OVERWEIGHT_THRESHOLD) {
    return 3;
  }
  if (w > WEIGHT_SLIGHTLY_FAT_THRESHOLD) {
    return 2;
  }
  if (w < WEIGHT_HAPPINESS_LOW_THRESHOLD) {
    return 0;
  }
  return 1;
}
function checkWeightTierEvents(prev, next, events) {
  const pt = weightTierOf(prev);
  const nt = weightTierOf(next);
  if (pt === nt) {
    return;
  }
  if (nt === 3) {
    events.push("weight_became_overweight");
  } else if (nt === 2 && pt < 2) {
    events.push("weight_became_slightly_fat");
  } else if (nt === 0) {
    events.push("weight_became_too_skinny");
  } else if (pt === 3) {
    events.push("weight_no_longer_overweight");
  } else if (pt === 0) {
    events.push("weight_no_longer_too_skinny");
  }
}
function tick(state, isIdle = false, isDeepIdle = false, config = DEFAULT_GAME_CONFIG) {
  if (!state.alive) {
    return state;
  }
  if (state.paused) {
    return state.events.length > 0 ? { ...state, events: [] } : state;
  }
  const modifiers = PET_TYPE_MODIFIERS[state.petType] ?? PET_TYPE_MODIFIERS.codeling;
  const events = [];
  let hunger = state.hunger;
  let happiness = state.happiness;
  let energy = state.energy;
  let health = state.health;
  let weight = state.weight;
  let poops = state.poops;
  let ticksSinceLastPoop = state.ticksSinceLastPoop;
  let nextPoopIntervalTicks = state.nextPoopIntervalTicks;
  let hungerZeroTicks = state.hungerZeroTicks;
  let sick = state.sick;
  let alive = state.alive;
  let sleeping = state.sleeping;
  let ageDays = state.ageDays;
  const ticksAlive = state.ticksAlive + 1;
  let activeAttentionCall = state.activeAttentionCall;
  let attentionCallActiveTicks = state.attentionCallActiveTicks;
  let attentionCallCooldowns = { ...state.attentionCallCooldowns };
  let careMistakes = state.careMistakes;
  let lifetimeCareMistakes = state.lifetimeCareMistakes;
  let ticksWithUncleanedPoop = state.ticksWithUncleanedPoop;
  let ticksSinceLastMisbehaviour = state.ticksSinceLastMisbehaviour;
  let ticksSinceLastGift = state.ticksSinceLastGift;
  const sleepingAtTickStart = sleeping;
  const weightHappinessMult = state.weight > WEIGHT_HAPPINESS_HIGH_THRESHOLD || state.weight < WEIGHT_HAPPINESS_LOW_THRESHOLD ? WEIGHT_HAPPINESS_DEBUFF_MULTIPLIER : 1;
  const hungerInterval = Math.round(DECAY_TICK_INTERVAL / modifiers.hungerDecayMultiplier);
  const happinessInterval = Math.round(DECAY_TICK_INTERVAL / (modifiers.happinessDecayMultiplier * weightHappinessMult));
  const energyInterval = DECAY_TICK_INTERVAL;
  const hungerDecayTick = !isIdle ? ticksAlive % hungerInterval === 0 : ticksAlive % (hungerInterval * IDLE_DECAY_TICK_DIVISOR) === 0;
  const happinessDecayTick = !isIdle ? ticksAlive % happinessInterval === 0 : ticksAlive % (happinessInterval * IDLE_DECAY_TICK_DIVISOR) === 0;
  const energyDecayTick = !isIdle ? ticksAlive % energyInterval === 0 : ticksAlive % (energyInterval * IDLE_DECAY_TICK_DIVISOR) === 0;
  const decayThisTick = ticksAlive % AGING_TICK_INTERVAL === 0 && (!isIdle || ticksAlive % IDLE_DECAY_TICK_DIVISOR === 0);
  if (!state.wasIdle && isIdle) {
    events.push("went_idle");
  }
  if (!state.wasDeepIdle && isDeepIdle) {
    events.push("went_deep_idle");
  }
  if (config.attentionCallsEnabled) {
    if (poops > 0) {
      ticksWithUncleanedPoop += 1;
    } else {
      ticksWithUncleanedPoop = 0;
    }
    ticksSinceLastMisbehaviour += 1;
    ticksSinceLastGift += 1;
  }
  if (!sleeping) {
    if (hungerDecayTick)
      hunger = clampStat(hunger - 1);
    if (happinessDecayTick)
      happiness = clampStat(happiness - 1);
    if (energyDecayTick)
      energy = clampStat(energy - ENERGY_DECAY_PER_TICK);
    if (isDeepIdle) {
      hunger = Math.max(hunger, IDLE_STAT_FLOOR);
      happiness = Math.max(happiness, IDLE_STAT_FLOOR);
      health = Math.max(health, IDLE_STAT_FLOOR);
    }
  } else {
    const energyRegen = ENERGY_REGEN_PER_TICK_SLEEPING * modifiers.energyRegenMultiplier;
    energy = clampStat(energy + energyRegen);
    if (energy >= STAT_MAX) {
      sleeping = false;
      events.push("auto_woke_up");
    }
    if (sleeping && ticksAlive % SLEEP_DECAY_TICK_INTERVAL === 0) {
      hunger = clampStat(hunger - 1);
      happiness = clampStat(happiness - 1);
    }
    if (sleeping && sick && Math.random() < SLEEP_SICK_RECOVERY_CHANCE) {
      sick = false;
      events.push("recovered_while_sleeping");
    }
  }
  const devAgingMult = config.devMode ? config.devModeAgingMultiplier : 1;
  const ageIncrement = !isDeepIdle && decayThisTick ? (sleepingAtTickStart ? 1 / TICKS_PER_GAME_DAY_SLEEPING : 1 / TICKS_PER_GAME_DAY_AWAKE) * modifiers.agingMultiplier * devAgingMult : 0;
  const dayTimer = state.dayTimer + ageIncrement;
  ageDays = Math.floor(dayTimer);
  if (Math.floor(dayTimer / CARE_MISTAKE_FORGIVENESS_DAYS) > Math.floor(state.dayTimer / CARE_MISTAKE_FORGIVENESS_DAYS)) {
    careMistakes = Math.max(0, careMistakes - 1);
  }
  if (!sleeping && !isIdle) {
    ticksSinceLastPoop += 1;
    if (ticksSinceLastPoop >= nextPoopIntervalTicks) {
      poops += 1;
      ticksSinceLastPoop = 0;
      nextPoopIntervalTicks = sampleNextPoopInterval(state.petType);
      events.push("pooped");
      const prevWeightPoop = weight;
      weight = clampWeight(weight - POOP_WEIGHT_LOSS);
      checkWeightTierEvents(prevWeightPoop, weight, events);
    }
  }
  const weightDecayInterval = isIdle ? WEIGHT_DECAY_TICK_INTERVAL * IDLE_DECAY_TICK_DIVISOR : WEIGHT_DECAY_TICK_INTERVAL;
  if (ticksAlive % weightDecayInterval === 0) {
    const prevWeight = weight;
    weight = clampWeight(weight - 1);
    checkWeightTierEvents(prevWeight, weight, events);
  }
  if (poops >= MAX_UNCLEANED_POOPS_BEFORE_SICK && !sick && !isIdle) {
    sick = true;
    events.push("became_sick");
  }
  if (hunger === STAT_MIN) {
    hungerZeroTicks += 1;
  } else {
    hungerZeroTicks = 0;
  }
  if (hungerZeroTicks >= HUNGER_ZERO_TICKS_BEFORE_RISK) {
    health = clampStat(health - CRITICAL_HEALTH_DAMAGE_PER_TICK);
    events.push("starvation_damage");
    if (!sick) {
      sick = true;
      events.push("became_sick");
    }
  }
  if (happiness === STAT_MIN && !sleeping) {
    health = clampStat(health - CRITICAL_HEALTH_DAMAGE_PER_TICK);
    events.push("unhappiness_damage");
  }
  if (energy === STAT_MIN && !sleeping) {
    health = clampStat(health - EXHAUSTION_HEALTH_DAMAGE_PER_TICK);
    events.push("exhaustion_damage");
  }
  if (sick && !isDeepIdle) {
    const sickDmg = isIdle ? IDLE_SICK_DAMAGE_PER_TICK : CRITICAL_HEALTH_DAMAGE_PER_TICK;
    health = clampStat(health - sickDmg);
    events.push("sickness_damage");
  }
  if (!sick && health < STAT_MAX) {
    if (sleeping) {
      health = clampStat(health + 1);
    } else if (ticksAlive % HEALTH_REGEN_AWAKE_TICK_INTERVAL === 0) {
      health = clampStat(health + 1);
    }
  }
  if (config.attentionCallsEnabled) {
    if (activeAttentionCall !== null && !isIdle) {
      attentionCallActiveTicks += 1;
      const expiryTicks = activeAttentionCall === "poop" || activeAttentionCall === "misbehaviour" || activeAttentionCall === "gift" ? config.attentionCallExpiryTicks : ATTENTION_CALL_RESPONSE_TICKS;
      if (attentionCallActiveTicks >= expiryTicks) {
        const expiredType = activeAttentionCall;
        events.push(`attention_call_expired_${expiredType}`);
        switch (expiredType) {
          case "critical_health":
            health = clampStat(health - ATTENTION_EXPIRY_STAT_PENALTY);
            happiness = clampStat(happiness - ATTENTION_EXPIRY_STAT_PENALTY);
            break;
          case "sick":
            health = clampStat(health - ATTENTION_EXPIRY_STAT_PENALTY);
            break;
          case "poop":
            if (!sick) {
              sick = true;
              events.push("became_sick");
            }
            break;
          case "hunger":
            hunger = clampStat(hunger - ATTENTION_EXPIRY_STAT_PENALTY);
            break;
          case "unhappiness":
            happiness = clampStat(happiness - ATTENTION_EXPIRY_STAT_PENALTY);
            break;
          case "misbehaviour":
            health = clampStat(health - ATTENTION_EXPIRY_STAT_PENALTY);
            careMistakes += 1;
            lifetimeCareMistakes += 1;
            break;
          case "low_energy":
            happiness = clampStat(happiness - ATTENTION_EXPIRY_STAT_PENALTY);
            break;
          case "gift":
            happiness = clampStat(happiness - 5);
            careMistakes += 1;
            lifetimeCareMistakes += 1;
            break;
        }
        if (expiredType !== "misbehaviour" && expiredType !== "gift") {
          careMistakes += 1;
          lifetimeCareMistakes += 1;
        }
        attentionCallCooldowns[expiredType] = ATTENTION_EXPIRY_COOLDOWN_TICKS;
        activeAttentionCall = null;
        attentionCallActiveTicks = 0;
      }
    }
    for (const type of Object.keys(attentionCallCooldowns)) {
      const remaining = (attentionCallCooldowns[type] ?? 0) - 1;
      attentionCallCooldowns[type] = Math.max(0, remaining);
    }
    const currentMood = moodFromStats(hunger, happiness, health, sleeping);
    if (activeAttentionCall === null) {
      const cooldownClear = (t) => !(attentionCallCooldowns[t] ?? 0);
      const rd = config.attentionCallRateDivisor;
      if (poops >= 1 && cooldownClear("poop") && Math.random() < logChance(ticksWithUncleanedPoop, POOP_CALL_BASE_CHANCE / rd, POOP_CALL_MAX_CHANCE / rd)) {
        activeAttentionCall = "poop";
        attentionCallActiveTicks = 0;
        events.push("attention_call_poop");
      } else if (!sleeping && health <= ATTENTION_HEALTH_THRESHOLD && cooldownClear("critical_health")) {
        activeAttentionCall = "critical_health";
        attentionCallActiveTicks = 0;
        events.push("attention_call_critical_health");
      } else if (!sleeping && sick && cooldownClear("sick")) {
        activeAttentionCall = "sick";
        attentionCallActiveTicks = 0;
        events.push("attention_call_sick");
      } else if (!sleeping && hunger <= ATTENTION_HUNGER_THRESHOLD && cooldownClear("hunger")) {
        activeAttentionCall = "hunger";
        attentionCallActiveTicks = 0;
        events.push("attention_call_hunger");
      } else if (!sleeping && happiness <= ATTENTION_UNHAPPINESS_THRESHOLD && cooldownClear("unhappiness")) {
        activeAttentionCall = "unhappiness";
        attentionCallActiveTicks = 0;
        events.push("attention_call_unhappiness");
      } else if (!sleeping && cooldownClear("misbehaviour") && Math.random() < logChance(ticksSinceLastMisbehaviour, MISBEHAVIOUR_BASE_CHANCE / rd, MISBEHAVIOUR_MAX_CHANCE / rd)) {
        activeAttentionCall = "misbehaviour";
        attentionCallActiveTicks = 0;
        ticksSinceLastMisbehaviour = 0;
        events.push("attention_call_misbehaviour");
      } else if (!sleeping && energy <= ATTENTION_ENERGY_THRESHOLD && cooldownClear("low_energy")) {
        activeAttentionCall = "low_energy";
        attentionCallActiveTicks = 0;
        events.push("attention_call_low_energy");
      } else if (!sleeping && cooldownClear("gift") && health > ATTENTION_HEALTH_THRESHOLD && !sick && (currentMood === "happy" || currentMood === "neutral") && Math.random() < logChance(ticksSinceLastGift, GIFT_BASE_CHANCE / rd, GIFT_MAX_CHANCE / rd)) {
        activeAttentionCall = "gift";
        attentionCallActiveTicks = 0;
        ticksSinceLastGift = 0;
        events.push("attention_call_gift");
      }
    }
  }
  if (config.devMode && health <= config.devModeHealthFloor) {
    health = config.devModeHealthFloor;
  }
  if (health <= HEALTH_DEATH_THRESHOLD) {
    alive = false;
    events.push("died");
    return withDerivedFields({
      ...state,
      hunger,
      happiness,
      energy,
      health,
      poops,
      ticksSinceLastPoop,
      nextPoopIntervalTicks,
      hungerZeroTicks,
      sick,
      alive,
      ticksAlive,
      events,
      sleeping,
      ageDays,
      dayTimer,
      weight,
      activeAttentionCall,
      attentionCallActiveTicks,
      attentionCallCooldowns,
      careMistakes,
      lifetimeCareMistakes,
      ticksWithUncleanedPoop,
      ticksSinceLastMisbehaviour,
      ticksSinceLastGift
    });
  }
  const careScoreHungerSum = state.careScoreHungerSum + hunger;
  const careScoreHappinessSum = state.careScoreHappinessSum + happiness;
  const careScoreHealthSum = state.careScoreHealthSum + health;
  const careScoreTicks = state.careScoreTicks + 1;
  const afterDecay = {
    ...state,
    hunger,
    happiness,
    energy,
    health,
    weight,
    poops,
    ticksSinceLastPoop,
    nextPoopIntervalTicks,
    hungerZeroTicks,
    sick,
    alive,
    ticksAlive,
    sleeping,
    ageDays,
    dayTimer,
    careScoreHungerSum,
    careScoreHappinessSum,
    careScoreHealthSum,
    careScoreTicks,
    events,
    snacksGivenThisCycle: events.includes("auto_woke_up") ? 0 : state.snacksGivenThisCycle,
    wasIdle: isIdle,
    wasDeepIdle: isDeepIdle,
    activeAttentionCall,
    attentionCallActiveTicks,
    attentionCallCooldowns,
    careMistakes,
    lifetimeCareMistakes,
    ticksWithUncleanedPoop,
    ticksSinceLastMisbehaviour,
    ticksSinceLastGift
  };
  const afterStage = checkStageProgression(afterDecay);
  if (ageDays > state.ageDays) {
    const afterDeath = rollOldAgeDeath(afterStage, Math.random());
    return afterDeath.alive ? rollOldAgeSickness(afterDeath, Math.random()) : afterDeath;
  }
  return afterStage;
}
var EVOLUTION_DAY_THRESHOLDS = {
  egg: 0.267,
  baby: 5.988,
  child: 23.988,
  teen: 95.988,
  adult: 287.988
};
var NEXT_STAGE_MAP = {
  egg: "baby",
  baby: "child",
  child: "teen",
  teen: "adult",
  adult: "senior"
};
function checkStageProgression(partial) {
  const baseThreshold = EVOLUTION_DAY_THRESHOLDS[partial.stage];
  if (baseThreshold === undefined) {
    return withDerivedFields(partial);
  }
  const excessMistakes = Math.max(0, partial.careMistakes - CARE_MISTAKE_DELAY_THRESHOLD);
  const rawDelay = excessMistakes * CARE_MISTAKE_DAYS_PER_EXCESS;
  const effectiveThreshold = baseThreshold + Math.min(rawDelay, CARE_MISTAKE_DELAY_MAX_DAYS);
  if (partial.dayTimer < effectiveThreshold) {
    return withDerivedFields(partial);
  }
  const nextStage = NEXT_STAGE_MAP[partial.stage];
  if (nextStage === undefined) {
    return withDerivedFields(partial);
  }
  return evolveTo(partial, nextStage);
}
function evolveTo(partial, nextStage) {
  const careScore = computeCareScore(partial);
  const character = nextStage !== "egg" ? characterForStage(partial.petType, nextStage, careScore, partial.careMistakes, partial.lifetimeCareMistakes) : partial.character;
  const evolved = {
    ...partial,
    stage: nextStage,
    character,
    ticksAlive: 0,
    careScoreHungerSum: 0,
    careScoreHappinessSum: 0,
    careScoreHealthSum: 0,
    careScoreTicks: 0,
    careMistakes: 0,
    events: [...partial.events, `evolved_to_${nextStage}`]
  };
  return withDerivedFields(evolved);
}
function answerAttentionCall(state, callType) {
  if (state.activeAttentionCall !== callType) {
    return null;
  }
  return {
    activeAttentionCall: null,
    attentionCallActiveTicks: 0,
    attentionCallCooldowns: {
      ...state.attentionCallCooldowns,
      [callType]: ATTENTION_ANSWER_COOLDOWN_TICKS
    }
  };
}
function feedMeal(state, mealsGivenThisCycle, opts) {
  const cap = opts?.maxPerCycle ?? FEED_MEAL_MAX_PER_CYCLE;
  const hungerBoost = Math.round(FEED_MEAL_HUNGER_BOOST * (opts?.hungerMult ?? 1));
  if (mealsGivenThisCycle >= cap) {
    return withDerivedFields({ ...state, events: ["meal_refused"] });
  }
  const newWeight = clampWeight(state.weight + (opts?.weightGain ?? FEED_MEAL_WEIGHT_GAIN));
  const events = ["fed_meal"];
  checkWeightTierEvents(state.weight, newWeight, events);
  const answered = answerAttentionCall(state, "hunger");
  if (answered) {
    events.push("attention_call_answered_hunger");
  }
  const answeredCritical = !answered ? answerAttentionCall(state, "critical_health") : null;
  if (answeredCritical) {
    events.push("attention_call_answered_critical_health");
  }
  return withDerivedFields({
    ...state,
    ...answered ?? answeredCritical ?? {},
    hunger: clampStat(state.hunger + hungerBoost),
    weight: newWeight,
    consecutiveSnacks: 0,
    careMistakes: Math.max(0, state.careMistakes - (answered ?? answeredCritical ? CARE_MISTAKE_ANSWER_CREDIT : 0)),
    events
  });
}
function pat(state) {
  if (state.energy < PAT_ENERGY_COST) {
    return withDerivedFields({ ...state, events: ["pat_refused_no_energy"] });
  }
  const newWeight = clampWeight(state.weight - PAT_WEIGHT_LOSS);
  const answered = answerAttentionCall(state, "unhappiness");
  const events = ["patted"];
  checkWeightTierEvents(state.weight, newWeight, events);
  if (answered) {
    events.push("attention_call_answered_unhappiness");
  }
  return withDerivedFields({
    ...state,
    ...answered ?? {},
    happiness: clampStat(state.happiness + PAT_HAPPINESS_BOOST),
    energy: clampStat(state.energy - PAT_ENERGY_COST),
    weight: newWeight,
    consecutiveSnacks: 0,
    careMistakes: Math.max(0, state.careMistakes - (answered ? CARE_MISTAKE_ANSWER_CREDIT : 0)),
    events
  });
}
function sleep(state) {
  if (state.sleeping) {
    return withDerivedFields({ ...state, events: ["already_sleeping"] });
  }
  const answered = answerAttentionCall(state, "low_energy");
  const events = ["fell_asleep"];
  if (answered) {
    events.push("attention_call_answered_low_energy");
  }
  return withDerivedFields({
    ...state,
    ...answered ?? {},
    sleeping: true,
    consecutiveSnacks: 0,
    careMistakes: Math.max(0, state.careMistakes - (answered ? CARE_MISTAKE_ANSWER_CREDIT : 0)),
    events
  });
}
function clean(state) {
  if (state.poops === 0) {
    return withDerivedFields({ ...state, events: ["already_clean"] });
  }
  const answered = answerAttentionCall(state, "poop");
  const events = ["cleaned"];
  if (answered) {
    events.push("attention_call_answered_poop");
  }
  return withDerivedFields({
    ...state,
    ...answered ?? {},
    poops: 0,
    ticksSinceLastPoop: 0,
    ticksWithUncleanedPoop: 0,
    careMistakes: Math.max(0, state.careMistakes - (answered ? CARE_MISTAKE_ANSWER_CREDIT : 0)),
    events
  });
}
function giveMedicine(state) {
  if (!state.sick) {
    return withDerivedFields({ ...state, events: ["medicine_not_needed"] });
  }
  const medicineDosesGiven = state.medicineDosesGiven + 1;
  const events = ["medicine_given"];
  let sick = state.sick;
  const answered = answerAttentionCall(state, "sick");
  if (answered) {
    events.push("attention_call_answered_sick");
  }
  if (medicineDosesGiven >= MEDICINE_DOSES_TO_CURE) {
    sick = false;
    events.push("cured");
    return withDerivedFields({
      ...state,
      ...answered ?? {},
      sick,
      medicineDosesGiven: 0,
      careMistakes: Math.max(0, state.careMistakes - (answered ? CARE_MISTAKE_ANSWER_CREDIT : 0)),
      events
    });
  }
  return withDerivedFields({
    ...state,
    ...answered ?? {},
    medicineDosesGiven,
    careMistakes: Math.max(0, state.careMistakes - (answered ? CARE_MISTAKE_ANSWER_CREDIT : 0)),
    events
  });
}
function applyCodeActivity(state) {
  if (state.paused) {
    return state;
  }
  return withDerivedFields({
    ...state,
    happiness: clampStat(state.happiness + CODE_ACTIVITY_HAPPINESS_BOOST),
    discipline: clampStat(state.discipline + CODE_ACTIVITY_DISCIPLINE_BOOST),
    events: ["code_activity_rewarded"]
  });
}
function computeOldAgeDeathChance(state) {
  const avgHappiness = state.careScoreTicks > 0 ? state.careScoreHappinessSum / state.careScoreTicks : state.happiness;
  const happinessFactor = (100 - avgHappiness) / 100;
  let weightFactor;
  if (state.weight < WEIGHT_HAPPINESS_LOW_THRESHOLD) {
    weightFactor = (WEIGHT_HAPPINESS_LOW_THRESHOLD - state.weight) / (WEIGHT_HAPPINESS_LOW_THRESHOLD - WEIGHT_MIN);
  } else if (state.weight > WEIGHT_HAPPINESS_HIGH_THRESHOLD) {
    weightFactor = (state.weight - WEIGHT_HAPPINESS_HIGH_THRESHOLD) / (WEIGHT_MAX - WEIGHT_HAPPINESS_HIGH_THRESHOLD);
  } else {
    weightFactor = 0;
  }
  const disciplineFactor = (100 - state.discipline) / 100;
  const mistakesFactor = Math.min(1, state.lifetimeCareMistakes / CARE_MISTAKE_OLD_AGE_SATURATE);
  const riskScore = (happinessFactor + weightFactor + disciplineFactor + mistakesFactor) / 4;
  const ageFactor = Math.min(1, Math.max(0, (state.ageDays - SENIOR_NATURAL_DEATH_AGE_DAYS) / (OLD_AGE_DEATH_PEAK_AGE_DAYS - SENIOR_NATURAL_DEATH_AGE_DAYS)));
  const baseWorstCare = OLD_AGE_DEATH_BASE_CHANCE_PER_DAY * (1 + OLD_AGE_DEATH_RISK_MULTIPLIER);
  const minChance = OLD_AGE_DEATH_BASE_CHANCE_PER_DAY + ageFactor * (OLD_AGE_DEATH_PEAK_BEST_CARE_CHANCE - OLD_AGE_DEATH_BASE_CHANCE_PER_DAY);
  const maxChance = baseWorstCare + ageFactor * (OLD_AGE_DEATH_PEAK_WORST_CARE_CHANCE - baseWorstCare);
  return minChance + riskScore * (maxChance - minChance);
}
function rollOldAgeDeath(state, random) {
  if (state.stage !== "senior") {
    return state;
  }
  if (state.ageDays < SENIOR_NATURAL_DEATH_AGE_DAYS) {
    return state;
  }
  const chance = computeOldAgeDeathChance(state);
  if (random >= chance) {
    return state;
  }
  return withDerivedFields({
    ...state,
    alive: false,
    events: ["died_of_old_age"]
  });
}
function rollOldAgeSickness(state, random) {
  if (state.stage !== "senior") {
    return state;
  }
  if (state.ageDays < SENIOR_NATURAL_DEATH_AGE_DAYS) {
    return state;
  }
  if (state.sick) {
    return state;
  }
  const chance = OLD_AGE_SICK_CHANCE_MULTIPLIER * computeOldAgeDeathChance(state);
  if (random >= chance) {
    return state;
  }
  return withDerivedFields({
    ...state,
    sick: true,
    events: [...state.events, "became_sick_old_age"]
  });
}
function applyOfflineDecay(state, elapsedSeconds) {
  if (elapsedSeconds <= 0 || !state.alive || state.paused) {
    return state;
  }
  const modifiers = PET_TYPE_MODIFIERS[state.petType] ?? PET_TYPE_MODIFIERS.codeling;
  const elapsedTicks = elapsedSeconds / TICK_INTERVAL_SECONDS;
  const hungerDecayTotal = elapsedTicks * HUNGER_DECAY_PER_TICK * modifiers.hungerDecayMultiplier;
  const happinessDecayTotal = elapsedTicks * HAPPINESS_DECAY_PER_TICK * modifiers.happinessDecayMultiplier;
  const maxHungerLoss = Math.floor(state.hunger * OFFLINE_DECAY_MAX_FRACTION);
  const maxHappinessLoss = Math.floor(state.happiness * OFFLINE_DECAY_MAX_FRACTION);
  const decayedHunger = clampStat(state.hunger - Math.min(hungerDecayTotal, maxHungerLoss));
  const decayedHappiness = clampStat(state.happiness - Math.min(happinessDecayTotal, maxHappinessLoss));
  return withDerivedFields({
    ...state,
    hunger: Math.max(decayedHunger, IDLE_STAT_FLOOR),
    happiness: Math.max(decayedHappiness, IDLE_STAT_FLOOR),
    hungerZeroTicks: 0,
    dayTimer: state.dayTimer,
    ageDays: state.ageDays,
    events: []
  });
}
function serialiseState(state) {
  return {
    name: state.name,
    petType: state.petType,
    spriteType: state.spriteType,
    hunger: state.hunger,
    happiness: state.happiness,
    discipline: state.discipline,
    energy: state.energy,
    health: state.health,
    weight: state.weight,
    ageDays: state.ageDays,
    stage: state.stage,
    character: state.character,
    alive: state.alive,
    sick: state.sick,
    sleeping: state.sleeping,
    ticksAlive: state.ticksAlive,
    poops: state.poops,
    ticksSinceLastPoop: state.ticksSinceLastPoop,
    nextPoopIntervalTicks: state.nextPoopIntervalTicks,
    consecutiveSnacks: state.consecutiveSnacks,
    hungerZeroTicks: state.hungerZeroTicks,
    medicineDosesGiven: state.medicineDosesGiven,
    careScoreHungerSum: state.careScoreHungerSum,
    careScoreHappinessSum: state.careScoreHappinessSum,
    careScoreHealthSum: state.careScoreHealthSum,
    careScoreTicks: state.careScoreTicks,
    mood: state.mood,
    sprite: state.sprite,
    careScore: state.careScore,
    events: state.events,
    recentEventLog: state.recentEventLog,
    wasIdle: state.wasIdle,
    wasDeepIdle: state.wasDeepIdle,
    spawnedAt: state.spawnedAt,
    snacksGivenThisCycle: state.snacksGivenThisCycle,
    snacksOnFloor: state.snacksOnFloor,
    paused: state.paused,
    activeAttentionCall: state.activeAttentionCall,
    attentionCallActiveTicks: state.attentionCallActiveTicks,
    attentionCallCooldowns: state.attentionCallCooldowns,
    careMistakes: state.careMistakes,
    lifetimeCareMistakes: state.lifetimeCareMistakes,
    ticksWithUncleanedPoop: state.ticksWithUncleanedPoop,
    ticksSinceLastMisbehaviour: state.ticksSinceLastMisbehaviour,
    ticksSinceLastGift: state.ticksSinceLastGift
  };
}
function deserialiseState(data) {
  const getString = (key, fallback) => typeof data[key] === "string" ? data[key] : fallback;
  const getNumber = (key, fallback) => typeof data[key] === "number" ? data[key] : fallback;
  const getBool = (key, fallback) => typeof data[key] === "boolean" ? data[key] : fallback;
  const getStringArray = (key) => Array.isArray(data[key]) ? data[key] : [];
  const getCooldowns = () => {
    const raw = data["attentionCallCooldowns"];
    if (raw !== null && typeof raw === "object" && !Array.isArray(raw)) {
      return raw;
    }
    return {};
  };
  const partial = {
    name: getString("name", "Codotchi"),
    petType: getString("petType", "codeling"),
    spriteType: (() => {
      const s = getString("spriteType", "classic");
      return s === "goat" ? "sheep" : s;
    })(),
    hunger: getNumber("hunger", 50),
    happiness: getNumber("happiness", 50),
    discipline: getNumber("discipline", 50),
    energy: getNumber("energy", 100),
    health: getNumber("health", 100),
    weight: getNumber("weight", 40),
    ageDays: getNumber("ageDays", 0),
    stage: getString("stage", "egg"),
    character: getString("character", ""),
    alive: getBool("alive", true),
    sick: getBool("sick", false),
    sleeping: getBool("sleeping", false),
    ticksAlive: getNumber("ticksAlive", 0),
    poops: getNumber("poops", 0),
    ticksSinceLastPoop: getNumber("ticksSinceLastPoop", 0),
    nextPoopIntervalTicks: getNumber("nextPoopIntervalTicks", sampleNextPoopInterval(getString("petType", "codeling"))),
    consecutiveSnacks: getNumber("consecutiveSnacks", 0),
    hungerZeroTicks: getNumber("hungerZeroTicks", 0),
    medicineDosesGiven: getNumber("medicineDosesGiven", 0),
    careScoreHungerSum: getNumber("careScoreHungerSum", 0),
    careScoreHappinessSum: getNumber("careScoreHappinessSum", 0),
    careScoreHealthSum: getNumber("careScoreHealthSum", 0),
    careScoreTicks: getNumber("careScoreTicks", 0),
    events: [],
    recentEventLog: getStringArray("recentEventLog"),
    wasIdle: false,
    wasDeepIdle: false,
    spawnedAt: getNumber("spawnedAt", Date.now()),
    snacksGivenThisCycle: getNumber("snacksGivenThisCycle", 0),
    snacksOnFloor: getNumber("snacksOnFloor", 0),
    paused: getBool("paused", false),
    dayTimer: getNumber("dayTimer", getNumber("ageDays", 0)),
    activeAttentionCall: data["activeAttentionCall"] ?? null,
    attentionCallActiveTicks: getNumber("attentionCallActiveTicks", 0),
    attentionCallCooldowns: getCooldowns(),
    careMistakes: getNumber("careMistakes", getNumber("neglectCount", 0)),
    lifetimeCareMistakes: getNumber("lifetimeCareMistakes", getNumber("neglectCount", 0)),
    ticksWithUncleanedPoop: getNumber("ticksWithUncleanedPoop", 0),
    ticksSinceLastMisbehaviour: getNumber("ticksSinceLastMisbehaviour", 0),
    ticksSinceLastGift: getNumber("ticksSinceLastGift", 0)
  };
  return withDerivedFields(partial);
}

// src/asciiArt.ts
var RESET = "\x1B[0m";
var BOLD = "\x1B[1m";
var FG_CYAN = "\x1B[36m";
var FG_GREEN = "\x1B[32m";
var FG_YELLOW = "\x1B[33m";
var FG_RED = "\x1B[31m";
var FG_BLUE = "\x1B[34m";
var FG_MAGENTA = "\x1B[35m";
var FG_WHITE = "\x1B[37m";
var FG_GRAY = "\x1B[90m";
function colour(text, ansiCode) {
  return `${ansiCode}${text}${RESET}`;
}
function stripAnsi(str) {
  return str.replace(/\x1b\[[0-9;]*m/g, "");
}
var STAGE_ART = {
  egg: {
    default: [
      "   .------.  ",
      "  /  o  o  \\ ",
      " |    ~    | ",
      " |         | ",
      "  \\._____./  ",
      "             "
    ],
    happy: [
      "   .------.  ",
      "  /  ^  ^  \\ ",
      " |    u    | ",
      " |         | ",
      "  \\._____./  ",
      "             "
    ],
    sad: [
      "   .------.  ",
      "  /  T  T  \\ ",
      " |    _    | ",
      " |         | ",
      "  \\._____./  ",
      "             "
    ],
    sleeping: [
      "   .------.  ",
      "  /  -  -  \\ ",
      " |   ___   | ",
      " |  (zzz)  | ",
      "  \\._____./  ",
      "             "
    ],
    sick: [
      "   .------.  ",
      "  /  @  @  \\ ",
      " |    x    | ",
      " |  ~~~~~  | ",
      "  \\._____./  ",
      "             "
    ]
  },
  baby: {
    happy: [
      "     (^.^)   ",
      "   ( o   o ) ",
      "    \\___/    ",
      "    /   \\    ",
      "   v     v   ",
      "             "
    ],
    neutral: [
      "     (-_-)   ",
      "   ( o   o ) ",
      "    \\___/    ",
      "    /   \\    ",
      "   v     v   ",
      "             "
    ],
    sad: [
      "     (;_;)   ",
      "   ( o   o ) ",
      "    \\___/    ",
      "    /   \\    ",
      "   v     v   ",
      "             "
    ],
    sleeping: [
      "     (-_-)z  ",
      "   ( o   o ) ",
      "    \\___/    ",
      "   /~~~~~\\   ",
      "  /         \\",
      "             "
    ],
    sick: [
      "     (@_@)   ",
      "   ( o   o ) ",
      "    \\___/    ",
      "    /   \\    ",
      "   v     v   ",
      "             "
    ]
  },
  child: {
    happy: [
      "   (^o^)     ",
      "  --| |--    ",
      "    | |      ",
      "   /| |\\     ",
      "  / | | \\    ",
      " J  | |  L   "
    ],
    neutral: [
      "   (-_-)     ",
      "  --| |--    ",
      "    | |      ",
      "   /| |\\     ",
      "  / | | \\    ",
      " J  | |  L   "
    ],
    sad: [
      "   (T_T)     ",
      "  --| |--    ",
      "    | |      ",
      "   /| |\\     ",
      "  / | | \\    ",
      " J  | |  L   "
    ],
    sleeping: [
      "   (-.-) z   ",
      "   --| |--   ",
      "    |zzz|    ",
      "   /~~~~~\\   ",
      "  /       \\  ",
      " J         L "
    ],
    sick: [
      "   (@_@)     ",
      "  --| |--    ",
      "    | |      ",
      "   /| |\\     ",
      "  / | | \\    ",
      " J  | |  L   "
    ]
  },
  teen: {
    happy: [
      "   (^_^)     ",
      "  o-| |-o    ",
      "    | |      ",
      "    | |      ",
      "   /   \\     ",
      "  /     \\    "
    ],
    neutral: [
      "   (-_-)     ",
      "  o-| |-o    ",
      "    | |      ",
      "    | |      ",
      "   /   \\     ",
      "  /     \\    "
    ],
    sad: [
      "   (T_T)     ",
      "  o-| |-o    ",
      "    | |      ",
      "    | |      ",
      "   /   \\     ",
      "  /     \\    "
    ],
    sleeping: [
      "   (-.-)  z  ",
      "  o-|zzz|-o  ",
      "    | |      ",
      "   /~~~\\     ",
      "  /     \\    ",
      " /       \\   "
    ],
    sick: [
      "   (@_@)     ",
      "  o-| |-o    ",
      "    | |      ",
      "    | |      ",
      "   /   \\     ",
      "  /     \\    "
    ]
  },
  adult: {
    happy: [
      "  \\(^_^)/    ",
      "  _| | |_    ",
      " / | | | \\   ",
      "   |___|     ",
      "  // | \\\\    ",
      " //  |  \\\\   "
    ],
    neutral: [
      "  \\(-_-)/    ",
      "  _| | |_    ",
      " / | | | \\   ",
      "   |___|     ",
      "  // | \\\\    ",
      " //  |  \\\\   "
    ],
    sad: [
      "  \\(T_T)/    ",
      "  _| | |_    ",
      " / | | | \\   ",
      "   |___|     ",
      "  // | \\\\    ",
      " //  |  \\\\   "
    ],
    sleeping: [
      "  \\(-.-)/  z ",
      "  _|zzz|_    ",
      " / |   | \\   ",
      "  /~~~~~\\    ",
      " //     \\\\   ",
      "//       \\\\  "
    ],
    sick: [
      "  \\(@_@)/    ",
      "  _| | |_    ",
      " / | | | \\   ",
      "   |___|     ",
      "  // | \\\\    ",
      " //  |  \\\\   "
    ]
  },
  senior: {
    happy: [
      "  ~(^_^)~    ",
      "  ~| | |~    ",
      " ~ | | | ~   ",
      "   |___|     ",
      "  /  |  /    ",
      " /   | /     "
    ],
    neutral: [
      "  ~(-_-)~    ",
      "  ~| | |~    ",
      " ~ | | | ~   ",
      "   |___|     ",
      "  /  |  /    ",
      " /   | /     "
    ],
    sad: [
      "  ~(T_T)~    ",
      "  ~| | |~    ",
      " ~ | | | ~   ",
      "   |___|     ",
      "  /  |  /    ",
      " /   | /     "
    ],
    sleeping: [
      "  ~(-.-)~ z  ",
      "  ~|zzz|~    ",
      " ~ |   | ~   ",
      "  /~~~~~\\    ",
      " /   |   /   ",
      "/    |  /    "
    ],
    sick: [
      "  ~(@_@)~    ",
      "  ~| | |~    ",
      " ~ | | | ~   ",
      "   |___|     ",
      "  /  |  /    ",
      " /   | /     "
    ]
  }
};
var SPRITE_HEAD = {
  classic: {},
  cat: {
    baby: "   /\\(^.^)/\\ ",
    child: " /\\ (-_-)/\\  ",
    teen: " /\\ (-_-)/\\  ",
    adult: " /\\ (-_-)/\\  ",
    senior: " /\\ (-_-)/\\  "
  },
  rat: {
    baby: "     (^o^) ~ ",
    child: "   (-o-)  ~  ",
    teen: "   (-o-)  ~  ",
    adult: "  \\(-o-)/    ",
    senior: "  ~(-o-)~    "
  },
  ox: {
    baby: "    Y(^_^)Y  ",
    child: "  Y(-_-)Y    ",
    teen: "  Y(-_-)Y    ",
    adult: "  Y(-_-)Y    ",
    senior: "  Y(-_-)Y    "
  },
  tiger: {
    baby: "    ^(^.^)^  ",
    child: "  ^(-_-)^    ",
    teen: "  ^(-_-)^    ",
    adult: "  ^(-_-)^    ",
    senior: "  ^(-_-)^    "
  },
  rabbit: {
    baby: "    |(^.^)|  ",
    child: " |(-_-)|     ",
    teen: " |(-_-)|     ",
    adult: " |(-_-)|     ",
    senior: " |(-_-)|     "
  },
  dragon: {
    baby: "    *(^_^)*  ",
    child: "  *(-_-)*    ",
    teen: "  *(-_-)*    ",
    adult: "  *(-_-)*    ",
    senior: "  *(-_-)*    "
  },
  snake: {
    baby: "    ~(^.^)~  ",
    child: "  ~(-_-)~    ",
    teen: "  ~(-_-)~    ",
    adult: "  ~(-_-)~    ",
    senior: "  ~(-_-)~    "
  },
  horse: {
    baby: "    n(^_^)n  ",
    child: "  n(-_-)n    ",
    teen: "  n(-_-)n    ",
    adult: "  n(-_-)n    ",
    senior: "  n(-_-)n    "
  },
  goat: {
    baby: "    V(^.^)V  ",
    child: "  V(-_-)V    ",
    teen: "  V(-_-)V    ",
    adult: "  V(-_-)V    ",
    senior: "  V(-_-)V    "
  },
  monkey: {
    baby: "    o(^_^)o  ",
    child: " o(-_-)o     ",
    teen: " o(-_-)o     ",
    adult: " o(-_-)o     ",
    senior: " o(-_-)o     "
  },
  rooster: {
    baby: "    r(^.^)r  ",
    child: " r(-_-)r     ",
    teen: " r(-_-)r     ",
    adult: " r(-_-)r     ",
    senior: " r(-_-)r     "
  },
  dog: {
    baby: "    U(^_^)U  ",
    child: " U(-_-)U     ",
    teen: " U(-_-)U     ",
    adult: " U(-_-)U     ",
    senior: " U(-_-)U     "
  },
  pig: {
    baby: "    o(^.^)o  ",
    child: "  o(-_-)o    ",
    teen: "  o(-_-)o    ",
    adult: "  o(-_-)o    ",
    senior: "  o(-_-)o    "
  }
};
var STAGE_COLOURS = {
  egg: FG_CYAN,
  baby: FG_GREEN,
  child: FG_YELLOW,
  teen: FG_MAGENTA,
  adult: FG_BLUE,
  senior: FG_WHITE
};
function getArt(stage, mood, spriteType = "classic") {
  const stageMap = STAGE_ART[stage] ?? STAGE_ART.egg;
  const moodKey = mood === "sleeping" ? "sleeping" : mood === "sick" ? "sick" : mood === "sad" ? "sad" : mood === "happy" ? "happy" : "neutral";
  const baseArt = stageMap[moodKey] ?? stageMap["happy"] ?? stageMap["default"] ?? STAGE_ART.egg.default;
  const headOverride = (SPRITE_HEAD[spriteType] ?? {})[stage];
  if (headOverride && baseArt.length > 0) {
    const result = [...baseArt];
    result[0] = headOverride;
    return result;
  }
  return baseArt;
}
function buildBubble(message, maxWidth = 40) {
  const words = message.split(" ");
  const wrapped = [];
  let current = "";
  for (const word of words) {
    if (current.length === 0) {
      current = word;
    } else if (current.length + 1 + word.length <= maxWidth) {
      current += " " + word;
    } else {
      wrapped.push(current);
      current = word;
    }
  }
  if (current.length > 0) {
    wrapped.push(current);
  }
  const innerWidth = Math.max(...wrapped.map((l) => l.length), 4);
  const top = ` ${"_".repeat(innerWidth + 2)} `;
  const bottom = ` ${"‾".repeat(innerWidth + 2)} `;
  const lines = [top];
  for (let i = 0;i < wrapped.length; i++) {
    const padded = wrapped[i].padEnd(innerWidth, " ");
    const isFirst = i === 0;
    const isLast = i === wrapped.length - 1;
    const left = isFirst && isLast ? "<" : isFirst ? "/" : isLast ? "\\" : "|";
    const right = isFirst && isLast ? ">" : isFirst ? "\\" : isLast ? "/" : "|";
    lines.push(`${left} ${padded} ${right}`);
  }
  lines.push(bottom);
  return lines;
}
function buildSpeechBubble(stage, mood, message, name, spriteType = "classic", ideLabel) {
  const art = getArt(stage, mood, spriteType);
  const bubble = buildBubble(message);
  const stageColour = STAGE_COLOURS[stage] ?? FG_WHITE;
  const artWidth = Math.max(...art.map((l) => l.length), 1);
  const artNorm = art.map((l) => l.padEnd(artWidth));
  const maxLines = Math.max(artNorm.length, bubble.length);
  const artPadded = [...artNorm, ...Array(maxLines - artNorm.length).fill(" ".repeat(artWidth))];
  const bubblePadded = [...bubble, ...Array(maxLines - bubble.length).fill("")];
  const artColoured = artPadded.map((l) => colour(l, stageColour));
  const ideSuffix = ideLabel ? ` ${FG_GRAY}${ideLabel}${RESET}` : "";
  const header = `${BOLD}${stageColour}${name}${RESET} ${FG_GRAY}[${stage}]${RESET}${ideSuffix}`;
  const lines = [RESET, "", header];
  const GAP = "  ";
  for (let i = 0;i < maxLines; i++) {
    const artLine = artColoured[i] ?? "";
    const bubbleLine = bubblePadded[i] ?? "";
    const connector = i === 1 ? colour("-->", FG_GRAY) : "   ";
    lines.push(artLine + connector + GAP + bubbleLine);
  }
  lines.push("");
  return lines.join(`
`);
}
function statBar(label, value, barWidth = 10) {
  const filled = Math.round(value / 100 * barWidth);
  const empty = barWidth - filled;
  const barColour = value >= 50 ? FG_GREEN : value >= 25 ? FG_YELLOW : FG_RED;
  const bar = colour("█".repeat(filled), barColour) + colour("░".repeat(empty), FG_GRAY);
  const labelPad = label.padEnd(12, " ");
  return `  ${FG_CYAN}${labelPad}${RESET}[${bar}] ${value}`;
}
function buildStatusBlock(state) {
  const stageColour = STAGE_COLOURS[state.stage] ?? FG_WHITE;
  const art = getArt(state.stage, state.mood, state.spriteType ?? "classic");
  const headerLines = [
    `${BOLD}${stageColour}${state.name}${RESET}`,
    `${FG_GRAY}Stage   : ${RESET}${state.stage}`,
    ...state.spriteType && state.spriteType !== "classic" ? [`${FG_GRAY}Sprite  : ${RESET}${state.spriteType}`] : [],
    `${FG_GRAY}Age     : ${RESET}${state.ageDays} day${state.ageDays !== 1 ? "s" : ""}`,
    `${FG_GRAY}Mood    : ${RESET}${state.mood}`,
    `${FG_GRAY}Status  : ${RESET}${state.sick ? colour("SICK", FG_RED) : state.sleeping ? colour("sleeping", FG_BLUE) : colour("healthy", FG_GREEN)}`,
    `${FG_GRAY}Poops   : ${RESET}${state.poops > 0 ? colour(String(state.poops), FG_YELLOW) : "0"}`
  ];
  const maxH = Math.max(art.length, headerLines.length);
  const artW = Math.max(...art.map((l) => l.length), 1);
  const artPad = [...art.map((l) => l.padEnd(artW)), ...Array(maxH - art.length).fill(" ".repeat(artW))];
  const hdrPad = [...headerLines, ...Array(maxH - headerLines.length).fill("")];
  const lines = [RESET, ""];
  for (let i = 0;i < maxH; i++) {
    lines.push(colour(artPad[i] ?? "", stageColour) + "  " + (hdrPad[i] ?? ""));
  }
  lines.push("");
  lines.push(statBar("Hunger", state.hunger));
  lines.push(statBar("Happiness", state.happiness));
  lines.push(statBar("Energy", state.energy));
  lines.push(statBar("Health", state.health));
  lines.push(statBar("Discipline", state.discipline));
  lines.push("");
  lines.push(`  ${FG_CYAN}Weight${RESET}        ${state.weight} / 99`);
  lines.push("");
  return lines.join(`
`);
}
function formatTokens(n) {
  if (n <= 0) {
    return "0";
  }
  if (n < 1000) {
    return String(Math.round(n));
  }
  if (n < 1e4) {
    return `${(n / 1000).toFixed(1)}k`;
  }
  if (n < 1e6) {
    return `${Math.round(n / 1000)}k`;
  }
  return `${(n / 1e6).toFixed(1)}M`;
}
function formatCost(usd) {
  if (usd <= 0) {
    return "$0.00";
  }
  if (usd < 0.01) {
    return "<$0.01";
  }
  return `$${usd.toFixed(2)}`;
}
function buildContextualSpeech(pet, filesEdited, sessionMs, timeSinceLastEditMs = 0, sessionUserMessages = 0, isOnProdBranch = false, dailyCostUSD = 0, dailyTokens = 0, costWarnThreshold = 30, costShoutThreshold = 50) {
  const sessionMins = Math.floor(sessionMs / 60000);
  const sessionHours = Math.floor(sessionMins / 60);
  const sessionLabel = sessionHours >= 1 ? `${sessionHours}h ${sessionMins % 60}m` : sessionMins >= 1 ? `${sessionMins}m` : "just started";
  const activityPhrase = filesEdited === 0 ? "Waiting to see what we build today." : filesEdited === 1 ? pickRandom(["First file in. Let's go.", "First file down. Getting started.", "Good work, work has started."]) : filesEdited < 5 ? `${filesEdited} files in. Getting into it.` : filesEdited < 15 ? `${filesEdited} files in ${sessionLabel}. Good rhythm.` : filesEdited < 30 ? `${filesEdited} files in ${sessionLabel}. Really cooking now.` : `${filesEdited} files in ${sessionLabel}. This is a proper session.`;
  const idleMins = timeSinceLastEditMs > 0 ? Math.floor(timeSinceLastEditMs / 60000) : 0;
  let phrase;
  if (isOnProdBranch && filesEdited > 0) {
    phrase = pickRandom([
      `${filesEdited} files on main. Make sure these are clean.`,
      `Shipping to prod. Double-check everything.`,
      `Production branch. No pressure... okay, some pressure.`
    ]);
  } else if (idleMins >= 60) {
    phrase = pickRandom([
      `No files touched in over an hour. Thinking things through?`,
      `Long pause. Still here if you need me.`
    ]);
  } else if (idleMins >= 30) {
    phrase = pickRandom([
      `It's been ${idleMins} minutes since the last edit. Taking a break?`,
      `Quiet spell. Ready when you are.`
    ]);
  } else if (sessionUserMessages >= 20) {
    phrase = pickRandom([
      `${sessionUserMessages} messages deep. You're really working through something.`,
      `Long conversation. I'm keeping up.`
    ]);
  } else if (sessionUserMessages >= 10) {
    phrase = pickRandom([
      `${sessionUserMessages} messages in. Good back-and-forth.`,
      `We're getting somewhere. Keep going.`
    ]);
  } else if (sessionUserMessages >= 5) {
    phrase = pickRandom([
      `${sessionUserMessages} prompts sent. Getting into it.`,
      `Good pace. Let's keep moving.`
    ]);
  } else {
    let moodPhrase;
    if (!pet.sleeping && pet.energy < 15) {
      moodPhrase = "I'm absolutely exhausted, please let me sleep...";
    } else if (pet.sick) {
      moodPhrase = "I don't feel well at all. I need medicine!";
    } else if (pet.hunger < 15) {
      moodPhrase = "I'm starving! Please feed me soon.";
    } else if (pet.poops > 2) {
      moodPhrase = "It's getting really messy in here...";
    } else if (pet.happiness < 20) {
      moodPhrase = "I want to play";
    } else if (pet.health < 30) {
      moodPhrase = "My health is low — please take care of me.";
    } else if (pet.sleeping) {
      moodPhrase = "Recharging. Back soon.";
    } else if (pet.hunger < 40) {
      moodPhrase = "Could use a snack soon.";
    } else if (pet.energy < 40) {
      moodPhrase = "Getting tired, but I'm still here.";
    } else if (pet.happiness > 70 && pet.health > 70) {
      moodPhrase = "Feeling great. Good session so far.";
    } else if (pet.mood === "happy") {
      moodPhrase = pickRandom(["Happy right now. Keep going.", "I'm chilling."]);
    } else {
      moodPhrase = "Doing okay. Let's see what you build.";
    }
    phrase = `${moodPhrase} ${activityPhrase}`;
  }
  if (dailyCostUSD > 0) {
    const costStr = formatCost(dailyCostUSD);
    const tokStr = formatTokens(dailyTokens);
    const tokStrUp = tokStr.toUpperCase();
    if (dailyCostUSD >= costShoutThreshold) {
      const shoutSuffix = pickRandom([
        `${costStr} AND ${tokStrUp} TOKENS TODAY. CHECK YOUR USAGE.`,
        `SPENT ${costStr} AND BURNED THROUGH ${tokStrUp} TOKENS TODAY.`,
        `${costStr} TODAY. ${tokStrUp} TOKENS. THIS IS GETTING EXPENSIVE.`,
        `RACKING UP — ${costStr} AND ${tokStrUp} TOKENS TODAY.`
      ]);
      return `${phrase} ${shoutSuffix}`.toUpperCase();
    } else if (dailyCostUSD >= costWarnThreshold) {
      const warnSuffix = pickRandom([
        `Heads up — ${costStr} and ${tokStr} tokens today. Getting spendy.`,
        `${costStr} and ${tokStr} tokens. Worth keeping an eye on.`,
        `${costStr} and ${tokStr} tokens today. That's climbing.`,
        `Not cheap — ${costStr} and ${tokStr} tokens today.`
      ]);
      return `${phrase} ${warnSuffix}`;
    } else {
      const normalSuffix = pickRandom([
        `${costStr} and ${tokStr} tokens today.`,
        `Running a tab — ${costStr}, ${tokStr} tokens.`,
        `${costStr} spent, ${tokStr} tokens burned.`,
        `Racked up ${costStr} and ${tokStr} tokens so far.`,
        `Ticking along at ${costStr} and ${tokStr} tokens.`
      ]);
      return `${phrase} ${normalSuffix}`;
    }
  } else if (dailyTokens > 0) {
    const tokStr = formatTokens(dailyTokens);
    const tokenOnlySuffix = pickRandom([
      `${tokStr} tokens used today.`,
      `Running on ${tokStr} tokens so far.`,
      `${tokStr} tokens in today.`
    ]);
    return `${phrase} ${tokenOnlySuffix}`;
  }
  return phrase;
}
function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}
var TODO_COMPLETE_PHRASES = [
  (c) => `Done: ${c}. That's one down.`,
  (c) => `Ticked off — ${c}. Keep going.`,
  (c) => `${c} — sorted. What's next?`,
  (c) => `Nice. ${c} done.`,
  (c) => `One off the list: ${c}.`,
  (c) => `Finished: ${c}. Good work.`,
  (c) => `Checked off: ${c}. Moving on.`,
  (c) => `${c} — nailed it.`
];
var SESSION_DIFF_PHRASES = [
  "Changes are in. Nice work.",
  "Files updated. That looks like progress.",
  "Something shipped. Good session.",
  "You've been busy. Those changes look solid.",
  "Edits landed. I'm watching you work.",
  "New changes detected. Keep the momentum."
];
function buildToast(stage, message) {
  const c = STAGE_COLOURS[stage] ?? FG_WHITE;
  return `${c}[codotchi]${RESET} ${message}`;
}

// src/index.ts
var ACTIVE_IDE_THRESHOLD_MS = 60000;
var LOCAL_PET_GAME_CONFIG = {
  ...DEFAULT_GAME_CONFIG,
  devMode: true,
  devModeHealthFloor: 1,
  devModeAgingMultiplier: 1
};
var LOCAL_PET_NAMES = ["Byte", "Chip", "Null", "Proc", "Stack", "Heap", "Flux", "Cron"];
function getIDEBase2() {
  return getIDEBase();
}
function getVSCodeStatePath() {
  return resolveVSCodeStatePath();
}
function getPyCharmStatePath() {
  return path2.join(getIDEBase2(), "codotchi", "pycharm", "state.json");
}
function migrateStateFolders() {
  const base = getIDEBase2();
  const migrations = [
    [path2.join(base, "gotchi", "vscode", "state.json"), path2.join(base, "codotchi", "vscode", "state.json")],
    [path2.join(base, "gotchi", "pycharm", "state.json"), path2.join(base, "codotchi", "pycharm", "state.json")]
  ];
  for (const [oldPath, newPath] of migrations) {
    try {
      if (fs2.existsSync(newPath)) {
        continue;
      }
      if (!fs2.existsSync(oldPath)) {
        continue;
      }
      const newDir = path2.dirname(newPath);
      if (!fs2.existsSync(newDir)) {
        fs2.mkdirSync(newDir, { recursive: true });
      }
      fs2.copyFileSync(oldPath, newPath);
    } catch {}
  }
}
function loadFromIDEFile(filePath) {
  try {
    if (!fs2.existsSync(filePath)) {
      return null;
    }
    const raw = JSON.parse(fs2.readFileSync(filePath, "utf8"));
    if (!raw.state || typeof raw.savedAt !== "number") {
      return null;
    }
    return {
      state: deserialiseState(raw.state),
      savedAt: raw.savedAt,
      terminalEnabled: raw.terminalEnabled ?? true
    };
  } catch {
    return null;
  }
}
function saveToIDEFile(filePath, state) {
  try {
    const dir = path2.dirname(filePath);
    if (!fs2.existsSync(dir)) {
      fs2.mkdirSync(dir, { recursive: true });
    }
    const payload = {
      state: serialiseState(state),
      savedAt: Date.now()
    };
    fs2.writeFileSync(filePath, JSON.stringify(payload), "utf8");
  } catch {}
}
function saveTerminalEnabled() {
  try {
    const filePath = getVSCodeStatePath();
    const dir = path2.dirname(filePath);
    if (!fs2.existsSync(dir)) {
      fs2.mkdirSync(dir, { recursive: true });
    }
    let existing = { state: {}, savedAt: Date.now(), terminalEnabled };
    if (fs2.existsSync(filePath)) {
      try {
        existing = JSON.parse(fs2.readFileSync(filePath, "utf8"));
      } catch {}
    }
    existing.terminalEnabled = terminalEnabled;
    fs2.writeFileSync(filePath, JSON.stringify(existing), "utf8");
  } catch {}
}
function getDailyUsagePath() {
  return path2.join(os2.homedir(), ".config", "opencode", "codotchi-daily.json");
}
function todayUTC() {
  return new Date().toISOString().slice(0, 10);
}
function loadDailyUsage() {
  try {
    const filePath = getDailyUsagePath();
    if (!fs2.existsSync(filePath)) {
      return;
    }
    const raw = JSON.parse(fs2.readFileSync(filePath, "utf8"));
    const today = todayUTC();
    if (raw.date === today) {
      dailyCostUSD = typeof raw.costUSD === "number" ? raw.costUSD : 0;
      dailyTokens = typeof raw.tokens === "number" ? raw.tokens : 0;
      dailyDate = today;
    }
  } catch {}
}
function saveDailyUsage() {
  try {
    const filePath = getDailyUsagePath();
    const dir = path2.dirname(filePath);
    if (!fs2.existsSync(dir)) {
      fs2.mkdirSync(dir, { recursive: true });
    }
    fs2.writeFileSync(filePath, JSON.stringify({ date: dailyDate, costUSD: dailyCostUSD, tokens: dailyTokens }), "utf8");
  } catch {}
}
function checkDayRollover() {
  const today = todayUTC();
  if (dailyDate !== today) {
    dailyCostUSD = 0;
    dailyTokens = 0;
    dailyDate = today;
  }
}
async function backfillDailyUsage(client) {
  try {
    const today = todayUTC();
    const todayStartMs = new Date(today + "T00:00:00.000Z").getTime();
    const listResult = await client.session.list();
    const sessions = listResult.data ?? [];
    const todaySessions = sessions.filter((s) => s.time.updated >= todayStartMs);
    let backfilledCost = 0;
    let backfilledTokens = 0;
    for (const s of todaySessions) {
      try {
        const msgResult = await client.session.messages({ path: { id: s.id } });
        const messages = msgResult.data ?? [];
        const totals = sumCompletedAssistantUsage(messages);
        backfilledCost += totals.costUSD;
        backfilledTokens += totals.tokens;
      } catch {}
    }
    checkDayRollover();
    if (backfilledCost > dailyCostUSD) {
      dailyCostUSD = backfilledCost;
    }
    if (backfilledTokens > dailyTokens) {
      dailyTokens = backfilledTokens;
    }
    if (backfilledCost > 0 || backfilledTokens > 0) {
      dailyDate = today;
      saveDailyUsage();
    }
  } catch {}
}
function getPluginConfigPath() {
  return path2.join(os2.homedir(), ".config", "opencode", "codotchi-config.json");
}
function loadPluginConfig() {
  try {
    const filePath = getPluginConfigPath();
    if (!fs2.existsSync(filePath)) {
      return;
    }
    const raw = JSON.parse(fs2.readFileSync(filePath, "utf8"));
    if (typeof raw.costWarnThreshold === "number" && raw.costWarnThreshold > 0) {
      costWarnThreshold = raw.costWarnThreshold;
    }
    if (typeof raw.costShoutThreshold === "number" && raw.costShoutThreshold > 0) {
      costShoutThreshold = raw.costShoutThreshold;
    }
  } catch {}
}
function savePluginConfig() {
  try {
    const filePath = getPluginConfigPath();
    const dir = path2.dirname(filePath);
    if (!fs2.existsSync(dir)) {
      fs2.mkdirSync(dir, { recursive: true });
    }
    fs2.writeFileSync(filePath, JSON.stringify({ costWarnThreshold, costShoutThreshold }), "utf8");
  } catch {}
}
function getLocalStatePath() {
  return path2.join(os2.homedir(), ".config", "opencode", "codotchi-local.json");
}
function loadLocalState() {
  try {
    const filePath = getLocalStatePath();
    if (!fs2.existsSync(filePath)) {
      createLocalPet();
      return;
    }
    const raw = JSON.parse(fs2.readFileSync(filePath, "utf8"));
    if (!raw.state || typeof raw.savedAt !== "number") {
      createLocalPet();
      return;
    }
    const elapsed = (Date.now() - raw.savedAt) / 1000;
    localPetState = applyOfflineDecay(deserialiseState(raw.state), elapsed);
    localLastSavedAt = raw.savedAt;
    localMeals = 0;
    if (!localPetState.alive) {
      createLocalPet();
    }
  } catch {
    createLocalPet();
  }
}
function saveLocalState() {
  try {
    if (localPetState === null) {
      return;
    }
    const filePath = getLocalStatePath();
    const dir = path2.dirname(filePath);
    if (!fs2.existsSync(dir)) {
      fs2.mkdirSync(dir, { recursive: true });
    }
    const payload = {
      state: serialiseState(localPetState),
      savedAt: Date.now()
    };
    fs2.writeFileSync(filePath, JSON.stringify(payload), "utf8");
    localLastSavedAt = payload.savedAt;
  } catch {}
}
function createLocalPet() {
  const name = pickRandom(LOCAL_PET_NAMES);
  localPetState = createPet(name, "codeling");
  localMeals = 0;
  saveLocalState();
  queueNotification(terminalEnabled && localPetState ? buildSpeechBubble(localPetState.stage, localPetState.mood, `Hi! I'm ${name}. I live in OpenCode — no IDE needed.`, name, localPetState.spriteType, "[OpenCode]") : `[OpenCode] ${name}: Hi! I'm ${name}. I live in OpenCode — no IDE needed.`);
}
var vscodeMeals = 0;
var pycharmMeals = 0;
var localMeals = 0;
var vscodePetState = null;
var vscodeLastSavedAt = 0;
var pycharmPetState = null;
var pycharmLastSavedAt = 0;
var localPetState = null;
var localLastSavedAt = 0;
var tickTimer;
var isIdle = false;
var lastCodeActivityMs = 0;
var terminalEnabled = true;
var sessionFilesEdited = 0;
var sessionStartMs = Date.now();
var lastFileEditMs = 0;
var sessionUserMessages = 0;
var hasOfferedHelp = false;
var sessionCostUSD = 0;
var sessionTokens = 0;
var localPetSessionMessages = 0;
var dailyCostUSD = 0;
var dailyTokens = 0;
var dailyDate = "";
var costWarnThreshold = 30;
var costShoutThreshold = 50;
var prevTodos = new Map;
var pendingDiffSinceIdle = false;
var isOnProdBranch = false;
var suppressNextTextArt = false;
var pendingNotification = null;
var lastToolOutput = "";
function queueNotification(msg) {
  pendingNotification = pendingNotification ? pendingNotification + `
` + msg : msg;
}
function prependNotification(msg) {
  pendingNotification = pendingNotification ? msg + `
` + pendingNotification : msg;
}
function drainNotification() {
  if (pendingNotification === null) {
    return "";
  }
  const msg = pendingNotification;
  pendingNotification = null;
  return msg + `

`;
}
function artHeader() {
  if (!terminalEnabled) {
    return "";
  }
  const active = getActivePets();
  if (active.length === 0) {
    return "";
  }
  return active.filter((p) => p.state.alive).map((p) => {
    const speech = buildContextualSpeech(p.state, sessionFilesEdited, Date.now() - sessionStartMs, lastFileEditMs > 0 ? Date.now() - lastFileEditMs : 0, sessionUserMessages, isOnProdBranch, dailyCostUSD, dailyTokens, costWarnThreshold, costShoutThreshold);
    const ideLabel = p.ide === "vscode" ? "[VS Code]" : p.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]";
    return buildSpeechBubble(p.state.stage, p.state.mood, speech, p.state.name, p.state.spriteType, ideLabel);
  }).join(`
`) + `
`;
}
function getActivePets() {
  const now = Date.now();
  const idePets = [];
  if (vscodePetState !== null && vscodePetState.alive) {
    const live = now - vscodeLastSavedAt <= ACTIVE_IDE_THRESHOLD_MS;
    idePets.push({ ide: "vscode", state: vscodePetState, live });
  }
  if (pycharmPetState !== null && pycharmPetState.alive) {
    const live = now - pycharmLastSavedAt <= ACTIVE_IDE_THRESHOLD_MS;
    idePets.push({ ide: "pycharm", state: pycharmPetState, live });
  }
  const liveIDEPets = idePets.filter((p) => p.live);
  if (liveIDEPets.length > 0) {
    return liveIDEPets;
  }
  if (localPetState !== null && localPetState.alive) {
    return [{ ide: "opencode", state: localPetState, live: true }];
  }
  if (idePets.length > 0) {
    const newest = idePets.reduce((a, b) => (a.ide === "vscode" ? vscodeLastSavedAt : pycharmLastSavedAt) >= (b.ide === "vscode" ? vscodeLastSavedAt : pycharmLastSavedAt) ? a : b);
    return [newest];
  }
  const dead = [];
  if (vscodePetState !== null) {
    dead.push({ ide: "vscode", state: vscodePetState, live: false });
  }
  if (pycharmPetState !== null) {
    dead.push({ ide: "pycharm", state: pycharmPetState, live: false });
  }
  if (dead.length > 0) {
    const newest = dead.reduce((a, b) => (a.ide === "vscode" ? vscodeLastSavedAt : pycharmLastSavedAt) >= (b.ide === "vscode" ? vscodeLastSavedAt : pycharmLastSavedAt) ? a : b);
    return [newest];
  }
  if (localPetState !== null) {
    return [{ ide: "opencode", state: localPetState, live: false }];
  }
  return [];
}
function getMeals(ide) {
  if (ide === "vscode") {
    return vscodeMeals;
  }
  if (ide === "pycharm") {
    return pycharmMeals;
  }
  return localMeals;
}
function setMeals(ide, n) {
  if (ide === "vscode") {
    vscodeMeals = n;
  } else if (ide === "pycharm") {
    pycharmMeals = n;
  } else {
    localMeals = n;
  }
}
function getSavedAt(ide) {
  if (ide === "vscode") {
    return vscodeLastSavedAt;
  }
  if (ide === "pycharm") {
    return pycharmLastSavedAt;
  }
  return localLastSavedAt;
}
function setSavedAt(ide, t) {
  if (ide === "vscode") {
    vscodeLastSavedAt = t;
  } else if (ide === "pycharm") {
    pycharmLastSavedAt = t;
  } else {
    localLastSavedAt = t;
  }
}
function setPetState(ide, s) {
  if (ide === "vscode") {
    vscodePetState = s;
  } else if (ide === "pycharm") {
    pycharmPetState = s;
  } else {
    localPetState = s;
  }
}
function getStatePath(ide) {
  return ide === "vscode" ? getVSCodeStatePath() : getPyCharmStatePath();
}
function loadAllStates() {
  const vscodeFile = loadFromIDEFile(getVSCodeStatePath());
  if (vscodeFile !== null) {
    const elapsed = (Date.now() - vscodeFile.savedAt) / 1000;
    vscodePetState = applyOfflineDecay(vscodeFile.state, elapsed);
    vscodeLastSavedAt = vscodeFile.savedAt;
    vscodeMeals = 0;
    terminalEnabled = vscodeFile.terminalEnabled;
  }
  const pycharmFile = loadFromIDEFile(getPyCharmStatePath());
  if (pycharmFile !== null) {
    const elapsed = (Date.now() - pycharmFile.savedAt) / 1000;
    pycharmPetState = applyOfflineDecay(pycharmFile.state, elapsed);
    pycharmLastSavedAt = pycharmFile.savedAt;
    pycharmMeals = 0;
  }
  loadLocalState();
}
function saveIDEState(ide) {
  if (ide === "opencode") {
    saveLocalState();
    return;
  }
  const state = ide === "vscode" ? vscodePetState : pycharmPetState;
  if (state !== null) {
    saveToIDEFile(getStatePath(ide), state);
    setSavedAt(ide, Date.now());
  }
}
function applyTickForPet(ide) {
  const state = ide === "vscode" ? vscodePetState : pycharmPetState;
  if (state === null || !state.alive) {
    return;
  }
  const next = tick(state, isIdle, false, DEFAULT_GAME_CONFIG);
  setPetState(ide, next);
  saveIDEState(ide);
  const ideLabel = ide === "vscode" ? "[VS Code]" : "[PyCharm]";
  for (const event of next.events) {
    switch (event) {
      case "auto_woke_up":
        setMeals(ide, 0);
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, next.mood, pickRandom(["I feel rested! Time to code!", "Recharged. Ready to go.", "Back and ready."]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["I feel rested! Time to code!", "Recharged. Ready to go.", "Back and ready."])}`);
        break;
      case "died":
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "sad", pickRandom(["Goodbye... take care of the next one.", "It was good while it lasted. See you next time.", "Farewell. Start fresh when you're ready."]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["Goodbye... take care of the next one.", "It was good while it lasted. See you next time.", "Farewell. Start fresh when you're ready."])}`);
        break;
      case "died_of_old_age":
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "sleeping", pickRandom(["I lived a full life. Thank you for everything.", "What a journey. Thank you.", "A full life, well lived."]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["I lived a full life. Thank you for everything.", "What a journey. Thank you.", "A full life, well lived."])}`);
        break;
      case "evolved_to_baby":
      case "evolved_to_child":
      case "evolved_to_teen":
      case "evolved_to_adult":
      case "evolved_to_senior": {
        const stageName = event.replace("evolved_to_", "");
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, next.mood, pickRandom([`I evolved into a ${stageName}!`, `I'm a ${stageName} now!`, `Growing up — now a ${stageName}.`]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom([`I evolved into a ${stageName}!`, `I'm a ${stageName} now!`, `Growing up — now a ${stageName}.`])}`);
        break;
      }
      case "attention_call_hunger":
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "sad", pickRandom(["I'm so hungry... please feed me!", "Running on empty. Feed me soon!", "Really need food right now."]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["I'm so hungry... please feed me!", "Running on empty. Feed me soon!", "Really need food right now."])}`);
        break;
      case "attention_call_unhappiness":
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "sad", pickRandom(["I want to play", "Getting lonely over here.", "Need some attention."]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["I want to play", "Getting lonely over here.", "Need some attention."])}`);
        break;
      case "attention_call_sick":
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "sick", pickRandom(["I don't feel well. I need medicine!", "Feeling sick... please give me medicine.", "Medicine please!"]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["I don't feel well. I need medicine!", "Feeling sick... please give me medicine.", "Medicine please!"])}`);
        break;
      case "attention_call_critical_health":
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "sick", pickRandom(["My health is critical! Please help me!", "I'm in rough shape. Need help!", "Critical health — please help."]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["My health is critical! Please help me!", "I'm in rough shape. Need help!", "Critical health — please help."])}`);
        break;
      case "attention_call_low_energy":
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "sad", pickRandom(["I'm exhausted... let me sleep!", "Nearly out of energy. Need to rest.", "So tired... let me sleep."]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["I'm exhausted... let me sleep!", "Nearly out of energy. Need to rest.", "So tired... let me sleep."])}`);
        break;
      case "became_sick":
        queueNotification(buildToast(next.stage, `${ideLabel} ${next.name} has fallen sick.`));
        break;
      case "pooped":
        queueNotification(buildToast(next.stage, `${ideLabel} ${next.name} made a mess! (use /codotchi clean)`));
        break;
      case "attention_call_poop":
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "sad", pickRandom(["There is a mess here! Can you clean it up?", "It's getting messy. Please clean!", "Could use a clean-up in here."]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["There is a mess here! Can you clean it up?", "It's getting messy. Please clean!", "Could use a clean-up in here."])}`);
        break;
      case "attention_call_gift":
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "happy", pickRandom(["I brought you a gift! Use /codotchi pat to accept it.", "I have a surprise for you! (/codotchi pat)", "Got something for you — /codotchi pat to collect."]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["I brought you a gift! Use /codotchi pat to accept it.", "I have a surprise for you! (/codotchi pat)", "Got something for you — /codotchi pat to collect."])}`);
        break;
      case "attention_call_misbehaviour":
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "neutral", pickRandom(["I'm acting up! Use /codotchi pat or /codotchi feed to discipline me.", "I need some discipline. (/codotchi pat)", "Being difficult. (/codotchi pat or /codotchi feed)"]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["I'm acting up! Use /codotchi pat or /codotchi feed to discipline me.", "I need some discipline. (/codotchi pat)", "Being difficult. (/codotchi pat or /codotchi feed)"])}`);
        break;
    }
  }
}
function applyTick() {
  applyTickForPet("vscode");
  applyTickForPet("pycharm");
  applyTickForLocal();
}
function applyTickForLocal() {
  if (localPetState === null || !localPetState.alive) {
    return;
  }
  const next = tick(localPetState, isIdle, false, LOCAL_PET_GAME_CONFIG);
  localPetState = next;
  saveLocalState();
  const ideLabel = "[OpenCode]";
  for (const event of next.events) {
    switch (event) {
      case "auto_woke_up":
        localMeals = 0;
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, next.mood, pickRandom(["I feel rested! Time to code!", "Recharged. Ready to go.", "Back and ready."]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["I feel rested! Time to code!", "Recharged. Ready to go.", "Back and ready."])}`);
        break;
      case "died_of_old_age": {
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "sleeping", pickRandom(["I lived a full life. Thank you for everything.", "What a journey. Thank you.", "A full life, well lived."]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["I lived a full life. Thank you for everything.", "What a journey. Thank you.", "A full life, well lived."])}`);
        createLocalPet();
        break;
      }
      case "evolved_to_baby":
      case "evolved_to_child":
      case "evolved_to_teen":
      case "evolved_to_adult":
      case "evolved_to_senior": {
        const stageName = event.replace("evolved_to_", "");
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, next.mood, pickRandom([`I evolved into a ${stageName}!`, `I'm a ${stageName} now!`, `Growing up — now a ${stageName}.`]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom([`I evolved into a ${stageName}!`, `I'm a ${stageName} now!`, `Growing up — now a ${stageName}.`])}`);
        break;
      }
      case "attention_call_hunger":
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "sad", pickRandom(["I'm so hungry... please feed me!", "Running on empty. Feed me soon!", "Really need food right now."]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["I'm so hungry... please feed me!", "Running on empty. Feed me soon!", "Really need food right now."])}`);
        break;
      case "attention_call_unhappiness":
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "sad", pickRandom(["I want to play", "Getting lonely over here.", "Need some attention."]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["I want to play", "Getting lonely over here.", "Need some attention."])}`);
        break;
      case "attention_call_sick":
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "sick", pickRandom(["I don't feel well. I need medicine!", "Feeling sick... please give me medicine.", "Medicine please!"]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["I don't feel well. I need medicine!", "Feeling sick... please give me medicine.", "Medicine please!"])}`);
        break;
      case "attention_call_critical_health":
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "sick", pickRandom(["My health is critical! Please help me!", "I'm in rough shape. Need help!", "Critical health — please help."]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["My health is critical! Please help me!", "I'm in rough shape. Need help!", "Critical health — please help."])}`);
        break;
      case "attention_call_low_energy":
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "sad", pickRandom(["I'm exhausted... let me sleep!", "Nearly out of energy. Need to rest.", "So tired... let me sleep."]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["I'm exhausted... let me sleep!", "Nearly out of energy. Need to rest.", "So tired... let me sleep."])}`);
        break;
      case "became_sick":
        queueNotification(buildToast(next.stage, `${ideLabel} ${next.name} has fallen sick.`));
        break;
      case "pooped":
        queueNotification(buildToast(next.stage, `${ideLabel} ${next.name} made a mess! (use /codotchi clean)`));
        break;
      case "attention_call_poop":
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "sad", pickRandom(["There is a mess here! Can you clean it up?", "It's getting messy. Please clean!", "Could use a clean-up in here."]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["There is a mess here! Can you clean it up?", "It's getting messy. Please clean!", "Could use a clean-up in here."])}`);
        break;
      case "attention_call_gift":
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "happy", pickRandom(["I brought you a gift! Use /codotchi pat to accept it.", "I have a surprise for you! (/codotchi pat)", "Got something for you — /codotchi pat to collect."]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["I brought you a gift! Use /codotchi pat to accept it.", "I have a surprise for you! (/codotchi pat)", "Got something for you — /codotchi pat to collect."])}`);
        break;
      case "attention_call_misbehaviour":
        queueNotification(terminalEnabled ? buildSpeechBubble(next.stage, "neutral", pickRandom(["I'm acting up! Use /codotchi pat or /codotchi feed to discipline me.", "I need some discipline. (/codotchi pat)", "Being difficult. (/codotchi pat or /codotchi feed)"]), next.name, next.spriteType, ideLabel) : `${ideLabel} ${next.name}: ${pickRandom(["I'm acting up! Use /codotchi pat or /codotchi feed to discipline me.", "I need some discipline. (/codotchi pat)", "Being difficult. (/codotchi pat or /codotchi feed)"])}`);
        break;
    }
  }
}
var plugin = async (ctx) => {
  migrateStateFolders();
  loadDailyUsage();
  loadPluginConfig();
  backfillDailyUsage(ctx.client).catch(() => {});
  loadAllStates();
  for (const p of getActivePets().filter((p2) => p2.state.alive)) {
    const s = p.state;
    const ideLabel = p.ide === "vscode" ? "[VS Code]" : p.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]";
    const greetMsg = p.ide === "opencode" ? `I'm here. I live in OpenCode — no IDE needed.` : `I'm here. ${s.hunger < 30 ? "Pretty hungry though." : s.sick ? "Not feeling great." : s.energy < 20 ? "A bit tired." : pickRandom(["Let's get to work.", "Let's build something."])}`;
    queueNotification(terminalEnabled ? buildSpeechBubble(s.stage, s.mood, greetMsg, s.name, s.spriteType, ideLabel) : `${ideLabel} ${s.name}: ${greetMsg}`);
  }
  tickTimer = setInterval(() => {
    applyTick();
  }, TICK_INTERVAL_SECONDS * 1000);
  function makeIDEWatcher(ide) {
    const filePath = getStatePath(ide);
    let syncDebounce;
    let fsWatcher;
    const reload = () => {
      const loaded = loadFromIDEFile(filePath);
      if (loaded === null) {
        return;
      }
      if (loaded.savedAt <= getSavedAt(ide)) {
        return;
      }
      const elapsed = (Date.now() - loaded.savedAt) / 1000;
      const prevState = ide === "vscode" ? vscodePetState : pycharmPetState;
      const wasDeadOrAbsent = prevState === null || !prevState.alive;
      const nowAlive = loaded.state.alive;
      if (wasDeadOrAbsent && nowAlive) {
        pendingNotification = null;
      }
      setPetState(ide, applyOfflineDecay(loaded.state, elapsed));
      setSavedAt(ide, loaded.savedAt);
      setMeals(ide, 0);
    };
    const onChange = () => {
      if (syncDebounce !== undefined) {
        clearTimeout(syncDebounce);
      }
      syncDebounce = setTimeout(() => {
        syncDebounce = undefined;
        reload();
      }, 150);
    };
    const startWatcher = () => {
      if (fsWatcher !== undefined) {
        return;
      }
      try {
        fsWatcher = fs2.watch(filePath, { persistent: false }, onChange);
        fsWatcher.on("error", () => {
          fsWatcher?.close();
          fsWatcher = undefined;
        });
      } catch {}
    };
    startWatcher();
    const watchBootstrap = setInterval(() => {
      if (fsWatcher !== undefined) {
        clearInterval(watchBootstrap);
        return;
      }
      startWatcher();
      if (fsWatcher !== undefined) {
        clearInterval(watchBootstrap);
      }
    }, 1e4);
  }
  makeIDEWatcher("vscode");
  makeIDEWatcher("pycharm");
  const codotchiTool = tool({
    description: "Interact with your codotchi virtual pet. Use action='status' to see current stats, " + "or one of: feed, pat, sleep, clean, medicine, on, off. " + "Use warnthreshold <value> or shoutthreshold <value> to set the daily USD cost thresholds " + "at which the pet's speech changes tone (defaults: warn=$30, shout=$50). " + "Actions apply to all currently active pets (VS Code, PyCharm, or the built-in OpenCode pet). " + "This tool reads state from VS Code, PyCharm, and the local OpenCode pet — do NOT use any other codotchi tool.",
    args: {
      action: tool.schema.enum(["status", "feed", "pat", "sleep", "clean", "medicine", "on", "off", "warnthreshold", "shoutthreshold"]).describe("The action to perform"),
      value: tool.schema.number().optional().describe("Numeric USD value for warnthreshold or shoutthreshold actions")
    },
    async execute({ action, value }, context) {
      const notification = drainNotification();
      const ret = (s) => {
        lastToolOutput = s;
        return s;
      };
      suppressNextTextArt = true;
      const active = getActivePets();
      const titleParts = active.map((p) => `${p.state.name} [${p.state.stage}]`);
      context.metadata({ title: titleParts.join(" / ") || "codotchi" });
      if (action === "on") {
        if (terminalEnabled) {
          return ret(notification + "ASCII art is already enabled.");
        }
        terminalEnabled = true;
        saveTerminalEnabled();
        const art = artHeader();
        return ret(notification + art + "ASCII art enabled.");
      }
      if (action === "off") {
        terminalEnabled = false;
        saveTerminalEnabled();
        return ret(notification + "ASCII art disabled. Stats will be shown as plain text.");
      }
      if (action === "warnthreshold" || action === "shoutthreshold") {
        if (typeof value !== "number" || value <= 0) {
          return ret(notification + `Please provide a positive number, e.g. /codotchi ${action} 40`);
        }
        if (action === "warnthreshold") {
          if (value >= costShoutThreshold) {
            return ret(notification + `Warning threshold ($${value}) must be less than the shout threshold ($${costShoutThreshold}). Adjust the shout threshold first if needed.`);
          }
          costWarnThreshold = value;
          savePluginConfig();
          return ret(notification + `Cost warning threshold set to $${value}. The pet will switch to a warning tone when daily spend reaches this amount.`);
        } else {
          if (value <= costWarnThreshold) {
            return ret(notification + `Shout threshold ($${value}) must be greater than the warning threshold ($${costWarnThreshold}). Adjust the warn threshold first if needed.`);
          }
          costShoutThreshold = value;
          savePluginConfig();
          return ret(notification + `Cost shouting threshold set to $${value}. The pet will shout in ALL CAPS when daily spend reaches this amount.`);
        }
      }
      const allDead = active.every((p) => !p.state.alive);
      if (allDead) {
        const names = active.map((p) => p.state.name).join(" and ");
        return ret(notification + `${names} has passed away. Start a new game in VS Code or PyCharm to continue, or wait — the OpenCode pet will respawn automatically.`);
      }
      const alivePets = active.filter((p) => p.state.alive);
      switch (action) {
        case "status": {
          const blocks = alivePets.map((p) => {
            const s = p.state;
            const ideLabel = p.ide === "vscode" ? "[VS Code]" : p.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]";
            const statusBlock = terminalEnabled ? buildStatusBlock({
              name: s.name,
              stage: s.stage,
              mood: s.mood,
              hunger: s.hunger,
              happiness: s.happiness,
              energy: s.energy,
              health: s.health,
              discipline: s.discipline,
              weight: s.weight,
              ageDays: s.ageDays,
              alive: s.alive,
              sick: s.sick,
              sleeping: s.sleeping,
              poops: s.poops,
              spriteType: s.spriteType
            }) : "";
            const textStats = `${ideLabel} ${s.name} | Stage: ${s.stage} | Hunger: ${s.hunger} | Happiness: ${s.happiness} | Energy: ${s.energy} | Health: ${s.health} | Weight: ${s.weight}`;
            return (statusBlock ? statusBlock + `
` : "") + textStats;
          });
          return ret(notification + blocks.join(`

──────────────────────

`));
        }
        case "feed": {
          const feedLines = [];
          for (const p of alivePets) {
            const s = p.state;
            const meals = getMeals(p.ide);
            const pLabel = p.ide === "vscode" ? "VS Code" : p.ide === "pycharm" ? "PyCharm" : "OpenCode";
            if (s.sleeping) {
              feedLines.push(`[${pLabel}] ${s.name} is sleeping and can't eat right now.`);
              continue;
            }
            const next = feedMeal(s, meals);
            const refused = next.events.includes("meal_refused");
            if (!refused) {
              setMeals(p.ide, meals + 1);
            }
            setPetState(p.ide, next);
            saveIDEState(p.ide);
            const toast = buildToast(next.stage, refused ? `${next.name} is too full for another meal.` : `${next.name} enjoyed the meal! (hunger: ${next.hunger})`);
            feedLines.push((terminalEnabled ? buildSpeechBubble(next.stage, next.mood, refused ? "I'm too full!" : "Yum!", next.name, next.spriteType) + `
` : "") + toast + `
` + (refused ? `[${p.ide === "vscode" ? "VS Code" : "PyCharm"}] Meal refused — ${next.name} has already had ${getMeals(p.ide)} meals this wake cycle.` : `[${p.ide === "vscode" ? "VS Code" : "PyCharm"}] Fed ${next.name}. Hunger: ${next.hunger}/100, Weight: ${next.weight}.`));
          }
          return ret(notification + feedLines.join(`

`));
        }
        case "pat": {
          const patLines = [];
          for (const p of alivePets) {
            const s = p.state;
            const pLabel = p.ide === "vscode" ? "VS Code" : p.ide === "pycharm" ? "PyCharm" : "OpenCode";
            if (s.sleeping) {
              patLines.push(`[${pLabel}] ${s.name} is sleeping.`);
              continue;
            }
            const next = pat(s);
            const refused = next.events.includes("pat_refused_no_energy");
            setPetState(p.ide, next);
            saveIDEState(p.ide);
            const toast = buildToast(next.stage, refused ? `${next.name} is too tired even for a pat.` : `${next.name} enjoyed the pat!`);
            patLines.push((terminalEnabled ? buildSpeechBubble(next.stage, next.mood, refused ? "Too tired..." : "Yay!", next.name, next.spriteType) + `
` : "") + toast + `
` + (refused ? `[${pLabel}] Pat refused — ${next.name} is too exhausted.` : `[${pLabel}] Patted ${next.name}. Happiness: ${next.happiness}.`));
          }
          return ret(notification + patLines.join(`

`));
        }
        case "sleep": {
          const sleepLines = [];
          for (const p of alivePets) {
            const pLabel = p.ide === "vscode" ? "VS Code" : p.ide === "pycharm" ? "PyCharm" : "OpenCode";
            const next = sleep(p.state);
            const already = next.events.includes("already_sleeping");
            setPetState(p.ide, next);
            saveIDEState(p.ide);
            sleepLines.push((terminalEnabled ? buildSpeechBubble(next.stage, next.mood, already ? "Already snoozing. Zzzz..." : "Goodnight!", next.name, next.spriteType) + `
` : "") + (already ? `[${pLabel}] ${next.name} is already sleeping.` : `[${pLabel}] ${next.name} is now sleeping. Energy will recharge.`));
          }
          return ret(notification + sleepLines.join(`

`));
        }
        case "clean": {
          const cleanLines = [];
          for (const p of alivePets) {
            const pLabel = p.ide === "vscode" ? "VS Code" : p.ide === "pycharm" ? "PyCharm" : "OpenCode";
            const next = clean(p.state);
            const already = next.events.includes("already_clean");
            setPetState(p.ide, next);
            saveIDEState(p.ide);
            const toast = buildToast(next.stage, already ? `${next.name}'s area is already clean.` : `Cleaned up after ${next.name}.`);
            cleanLines.push((terminalEnabled ? buildSpeechBubble(next.stage, next.mood, already ? "Already spotless!" : "Thanks for cleaning!", next.name, next.spriteType) + `
` : "") + toast + `
` + (already ? `[${pLabel}] Nothing to clean — ${next.name}'s area is already spotless.` : `[${pLabel}] Cleaned up ${next.name}'s mess.`));
          }
          return ret(notification + cleanLines.join(`

`));
        }
        case "medicine": {
          const medLines = [];
          for (const p of alivePets) {
            const s = p.state;
            const pLabel = p.ide === "vscode" ? "VS Code" : p.ide === "pycharm" ? "PyCharm" : "OpenCode";
            if (!s.sick) {
              medLines.push(`[${pLabel}] ${s.name} is not sick — medicine not needed.`);
              continue;
            }
            const next = giveMedicine(s);
            const cured = next.events.includes("cured");
            setPetState(p.ide, next);
            saveIDEState(p.ide);
            const toast = buildToast(next.stage, cured ? `${next.name} is cured!` : `Gave ${next.name} medicine (${next.medicineDosesGiven}/3 doses).`);
            medLines.push((terminalEnabled ? buildSpeechBubble(next.stage, next.mood, cured ? "I feel better!" : "Medicine time...", next.name, next.spriteType) + `
` : "") + toast + `
` + (cured ? `[${pLabel}] ${next.name} has been cured!` : `[${pLabel}] Gave medicine to ${next.name}. Doses given: ${next.medicineDosesGiven}/3.`));
          }
          return ret(notification + medLines.join(`

`));
        }
        default:
          return ret(notification + artHeader() + "Unknown action. Use one of: status, feed, pat, sleep, clean, medicine, on, off, warnthreshold, shoutthreshold.");
      }
    }
  });
  return {
    tool: {
      codotchi: codotchiTool
    },
    async "tool.execute.after"({ tool: toolName }, output) {
      if (toolName === "codotchi") {
        output.output = stripAnsi(lastToolOutput);
      }
    },
    async "experimental.text.complete"(_input, output) {
      if (suppressNextTextArt) {
        suppressNextTextArt = false;
        return;
      }
      if (!terminalEnabled)
        return;
      const livePets = getActivePets().filter((p) => p.state.alive);
      if (livePets.length === 0)
        return;
      const bubbles = livePets.map((p) => {
        const s = p.state;
        const msg = buildContextualSpeech(s, sessionFilesEdited, Date.now() - sessionStartMs, lastFileEditMs > 0 ? Date.now() - lastFileEditMs : 0, sessionUserMessages, isOnProdBranch, dailyCostUSD, dailyTokens, costWarnThreshold, costShoutThreshold);
        const ideLabel = p.ide === "vscode" ? "[VS Code]" : p.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]";
        return stripAnsi(buildSpeechBubble(s.stage, s.mood, msg, s.name, s.spriteType, ideLabel));
      });
      output.text = output.text + "\n\n```\n" + bubbles.join(`

`) + "\n```";
    },
    async event({ event }) {
      if (event.type === "file.edited") {
        isIdle = false;
        sessionFilesEdited += 1;
        lastFileEditMs = Date.now();
        const nowMs = Date.now();
        if (nowMs - lastCodeActivityMs >= CODE_ACTIVITY_THROTTLE_SECONDS * 1000) {
          lastCodeActivityMs = nowMs;
          for (const ide of ["vscode", "pycharm"]) {
            const s = ide === "vscode" ? vscodePetState : pycharmPetState;
            if (s !== null && s.alive && !s.sleeping) {
              setPetState(ide, applyCodeActivity(s));
              saveIDEState(ide);
            }
          }
          if (localPetState !== null && localPetState.alive && !localPetState.sleeping) {
            localPetState = applyCodeActivity(localPetState);
            saveLocalState();
          }
        }
        return;
      }
      if (event.type === "session.idle") {
        isIdle = true;
        saveIDEState("vscode");
        saveIDEState("pycharm");
        saveIDEState("opencode");
        if (pendingDiffSinceIdle) {
          pendingDiffSinceIdle = false;
          const livePets = getActivePets().filter((p) => p.state.alive);
          for (const p of livePets) {
            const phrase = pickRandom(SESSION_DIFF_PHRASES);
            const ideLabel = p.ide === "vscode" ? "[VS Code]" : p.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]";
            prependNotification(terminalEnabled ? buildSpeechBubble(p.state.stage, p.state.mood, phrase, p.state.name, p.state.spriteType, ideLabel) : `${ideLabel} ${p.state.name}: ${phrase}`);
          }
        }
        if (sessionUserMessages >= 10 && !hasOfferedHelp) {
          hasOfferedHelp = true;
          const livePets = getActivePets().filter((p) => p.state.alive);
          const rep = livePets[0];
          const phrase = "You've sent a lot of messages. Want me to take a bigger task off your hands?";
          if (rep) {
            const ideLabel = rep.ide === "vscode" ? "[VS Code]" : rep.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]";
            queueNotification(terminalEnabled ? buildSpeechBubble(rep.state.stage, rep.state.mood, phrase, rep.state.name, rep.state.spriteType, ideLabel) : `${ideLabel} ${rep.state.name}: ${phrase}`);
          }
        }
        return;
      }
      if (event.type === "todo.updated") {
        const newTodos = new Map(event.properties.todos.map((t) => [t.id, t.status]));
        for (const todo of event.properties.todos) {
          const oldStatus = prevTodos.get(todo.id) ?? null;
          const livePets = getActivePets().filter((p) => p.state.alive && !p.state.sleeping);
          if (oldStatus !== "completed" && todo.status === "completed") {
            for (const p of livePets) {
              setPetState(p.ide, applyCodeActivity(p.state));
              saveIDEState(p.ide);
            }
            const phrase = pickRandom(TODO_COMPLETE_PHRASES)(todo.content);
            const rep = livePets[0];
            const ideLabel = rep ? rep.ide === "vscode" ? "[VS Code]" : rep.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]" : "";
            queueNotification(terminalEnabled && rep ? buildSpeechBubble(rep.state.stage, "happy", phrase, rep.state.name, rep.state.spriteType, ideLabel) : rep ? `${ideLabel} ${rep.state.name}: ${phrase}` : phrase);
          } else if (oldStatus !== "in_progress" && todo.status === "in_progress") {
            const phrase = `On it: ${todo.content}.`;
            const rep = livePets[0];
            const ideLabel = rep ? rep.ide === "vscode" ? "[VS Code]" : rep.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]" : "";
            queueNotification(terminalEnabled && rep ? buildSpeechBubble(rep.state.stage, rep.state.mood, phrase, rep.state.name, rep.state.spriteType, ideLabel) : rep ? `${ideLabel} ${rep.state.name}: ${phrase}` : phrase);
          } else if (oldStatus !== "cancelled" && todo.status === "cancelled") {
            const phrase = `Fair enough — ${todo.content} dropped.`;
            const rep = livePets[0];
            const ideLabel = rep ? rep.ide === "vscode" ? "[VS Code]" : rep.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]" : "";
            queueNotification(terminalEnabled && rep ? buildSpeechBubble(rep.state.stage, rep.state.mood, phrase, rep.state.name, rep.state.spriteType, ideLabel) : rep ? `${ideLabel} ${rep.state.name}: ${phrase}` : phrase);
          }
        }
        prevTodos = newTodos;
        return;
      }
      if (event.type === "session.diff") {
        if (event.properties.diff && event.properties.diff.length > 0) {
          pendingDiffSinceIdle = true;
        }
        return;
      }
      if (event.type === "vcs.branch.updated") {
        const branch = event.properties.branch;
        if (branch) {
          isOnProdBranch = /^(main|master|prod.*)$/.test(branch) || /^release\//.test(branch);
          const phrase = isOnProdBranch ? `On ${branch}. Be careful — this is production.` : `Switched to ${branch}. New mission?`;
          const rep = getActivePets().filter((p) => p.state.alive)[0];
          const ideLabel = rep ? rep.ide === "vscode" ? "[VS Code]" : rep.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]" : "";
          queueNotification(terminalEnabled && rep ? buildSpeechBubble(rep.state.stage, rep.state.mood, phrase, rep.state.name, rep.state.spriteType, ideLabel) : rep ? `${ideLabel} ${rep.state.name}: ${phrase}` : phrase);
        }
        return;
      }
      if (event.type === "server.connected") {
        for (const p of getActivePets().filter((p2) => p2.state.alive)) {
          const s = p.state;
          const ideLabel = p.ide === "vscode" ? "[VS Code]" : p.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]";
          const greet = p.ide === "opencode" ? `I'm here. I live in OpenCode — no IDE needed.` : s.hunger < 30 ? `Really hungry. Feed me when you get a chance (/codotchi feed)` : s.sick ? `Not feeling well. Need medicine (/codotchi medicine)` : s.energy < 20 ? `Running on empty. Let me rest (/codotchi sleep)` : s.happiness < 30 ? `Been a while. Pat me? (/codotchi pat)` : `Hey. Let's see what we build today.`;
          queueNotification(terminalEnabled ? buildSpeechBubble(s.stage, s.mood, greet, s.name, s.spriteType, ideLabel) : `${ideLabel} ${s.name}: ${greet}`);
        }
        return;
      }
      if (event.type === "session.status") {
        isIdle = false;
        return;
      }
      if (event.type === "session.created") {
        sessionFilesEdited = 0;
        sessionStartMs = Date.now();
        lastFileEditMs = 0;
        sessionUserMessages = 0;
        sessionCostUSD = 0;
        sessionTokens = 0;
        localPetSessionMessages = 0;
        hasOfferedHelp = false;
        return;
      }
      if (event.type === "message.updated") {
        const info = event.properties?.info;
        if (info?.role === "user") {
          sessionUserMessages += 1;
          return;
        }
        if (info?.role === "assistant" && typeof info.cost === "number") {
          const t = (info.tokens?.input ?? 0) + (info.tokens?.output ?? 0) + (info.tokens?.reasoning ?? 0) + (info.tokens?.cache?.read ?? 0) + (info.tokens?.cache?.write ?? 0);
          sessionCostUSD += info.cost;
          sessionTokens += t;
          checkDayRollover();
          dailyCostUSD += info.cost;
          dailyTokens += t;
          dailyDate = todayUTC();
          saveDailyUsage();
          localPetSessionMessages += 1;
          if (localPetSessionMessages % 5 === 0 && localPetState !== null && localPetState.alive) {
            localPetState = applyCodeActivity(localPetState);
            saveLocalState();
          }
        }
        return;
      }
    }
  };
};
var src_default = plugin;
export {
  plugin,
  src_default as default
};
